package com.courseregistration.view;

import com.courseregistration.controller.RegistrationController;
import com.courseregistration.util.DatabaseUtil;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class RegistrationControlPanel extends JPanel {
    private RegistrationController registrationController;
    private JLabel lblStatus;
    private JButton btnOpenRegistration, btnCloseRegistration;
    
    public RegistrationControlPanel() {
        registrationController = new RegistrationController();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        updateStatus();
    }
    
    private void initializeComponents() {
        lblStatus = new JLabel("Registration Status: Loading...");
        lblStatus.setFont(new Font("Arial", Font.BOLD, 16));
        
        btnOpenRegistration = new JButton("Open Registration");
        btnCloseRegistration = new JButton("Close Registration");
        
        btnOpenRegistration.setBackground(Color.GREEN);
        btnCloseRegistration.setBackground(Color.RED);
        btnOpenRegistration.setForeground(Color.WHITE);
        btnCloseRegistration.setForeground(Color.WHITE);
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Main control panel
        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.setBackground(Color.WHITE);
        controlPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(30, 30, 30, 30)
        ));
        
        // Title
        JLabel titleLabel = new JLabel("Registration Period Control");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(51, 51, 51));
        titleLabel.setHorizontalAlignment(JLabel.CENTER);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        
        // Status panel with card design
        JPanel statusPanel = new JPanel();
        statusPanel.setBackground(Color.WHITE);
        statusPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        lblStatus.setFont(new Font("Arial", Font.BOLD, 18));
        lblStatus.setHorizontalAlignment(JLabel.CENTER);
        statusPanel.add(lblStatus);
        
        // Button panel with improved styling
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        buttonPanel.setBackground(Color.WHITE);
        
        // Style buttons
        btnOpenRegistration.setFont(new Font("Arial", Font.BOLD, 14));
        btnOpenRegistration.setBorder(BorderFactory.createEmptyBorder(12, 25, 12, 25));
        btnOpenRegistration.setFocusPainted(false);
        
        btnCloseRegistration.setFont(new Font("Arial", Font.BOLD, 14));
        btnCloseRegistration.setBorder(BorderFactory.createEmptyBorder(12, 25, 12, 25));
        btnCloseRegistration.setFocusPainted(false);
        
        buttonPanel.add(btnOpenRegistration);
        buttonPanel.add(btnCloseRegistration);
        
        controlPanel.add(titleLabel, BorderLayout.NORTH);
        controlPanel.add(statusPanel, BorderLayout.CENTER);
        controlPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(controlPanel, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnOpenRegistration.addActionListener(e -> openRegistration());
        btnCloseRegistration.addActionListener(e -> closeRegistration());
    }
    
    private void openRegistration() {
        if (setRegistrationStatus(true)) {
            JOptionPane.showMessageDialog(this, "Registration period opened successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            updateStatus();
        }
    }
    
    private void closeRegistration() {
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to close registration?\nStudents will not be able to register or modify their courses.",
            "Confirm Close Registration",
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            if (setRegistrationStatus(false)) {
                JOptionPane.showMessageDialog(this, "Registration period closed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                updateStatus();
            }
        }
    }
    
    private boolean setRegistrationStatus(boolean isOpen) {
        createSystemSettingsTable();
        
        String sql = "INSERT INTO system_settings (setting_key, setting_value) VALUES ('registration_open', ?) " +
                    "ON DUPLICATE KEY UPDATE setting_value = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            String value = isOpen ? "true" : "false";
            stmt.setString(1, value);
            stmt.setString(2, value);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
    
    private void createSystemSettingsTable() {
        String sql = "CREATE TABLE IF NOT EXISTS system_settings (" +
                    "setting_key VARCHAR(50) PRIMARY KEY, " +
                    "setting_value VARCHAR(255) NOT NULL" +
                    ")";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            
            stmt.executeUpdate(sql);
            
        } catch (SQLException e) {
            System.err.println("Error creating system_settings table: " + e.getMessage());
        }
    }
    
    private void updateStatus() {
        boolean isOpen = isRegistrationOpen();
        if (isOpen) {
            lblStatus.setText("Registration Status: OPEN");
            lblStatus.setForeground(Color.GREEN);
            btnOpenRegistration.setEnabled(false);
            btnCloseRegistration.setEnabled(true);
        } else {
            lblStatus.setText("Registration Status: CLOSED");
            lblStatus.setForeground(Color.RED);
            btnOpenRegistration.setEnabled(true);
            btnCloseRegistration.setEnabled(false);
        }
    }
    
    public static boolean isRegistrationOpen() {
        createSystemSettingsTableStatic();
        
        String sql = "SELECT setting_value FROM system_settings WHERE setting_key = 'registration_open'";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return "true".equals(rs.getString("setting_value"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking registration status: " + e.getMessage());
        }
        
        return true; // Default to open if no setting found
    }
    
    private static void createSystemSettingsTableStatic() {
        String sql = "CREATE TABLE IF NOT EXISTS system_settings (" +
                    "setting_key VARCHAR(50) PRIMARY KEY, " +
                    "setting_value VARCHAR(255) NOT NULL" +
                    ")";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            
            stmt.executeUpdate(sql);
            
        } catch (SQLException e) {
            System.err.println("Error creating system_settings table: " + e.getMessage());
        }
    }
}