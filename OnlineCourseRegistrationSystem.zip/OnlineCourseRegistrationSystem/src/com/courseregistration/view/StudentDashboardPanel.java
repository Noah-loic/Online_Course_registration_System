package com.courseregistration.view;

import com.courseregistration.controller.*;
import com.courseregistration.model.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class StudentDashboardPanel extends JPanel {
    private RegistrationController registrationController;
    private CourseController courseController;
    private User currentUser;
    
    public StudentDashboardPanel(User currentUser) {
        this.currentUser = currentUser;
        registrationController = new RegistrationController();
        courseController = new CourseController();
        
        initializeComponents();
        setupLayout();
    }
    
    private void initializeComponents() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Welcome panel
        JPanel welcomePanel = new JPanel();
        JLabel welcomeLabel = new JLabel("Welcome, " + currentUser.getUsername() + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomePanel.add(welcomeLabel);
        
        // Stats panel
        JPanel statsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        
        // Get student registrations
        List<Registration> registrations = registrationController.getStudentRegistrations(currentUser.getUserId());
        long activeRegistrations = registrations.stream().filter(r -> "ACTIVE".equals(r.getStatus())).count();
        long completedCourses = registrations.stream().filter(r -> "COMPLETED".equals(r.getStatus())).count();
        
        // Calculate total credits
        int totalCredits = 0;
        for (Registration reg : registrations) {
            if ("ACTIVE".equals(reg.getStatus()) || "COMPLETED".equals(reg.getStatus())) {
                Course course = courseController.getCourseByCode(reg.getCourseCode());
                if (course != null) {
                    totalCredits += course.getCredits();
                }
            }
        }
        
        statsPanel.add(createStatCard("Current Courses", String.valueOf(activeRegistrations), Color.BLUE));
        statsPanel.add(createStatCard("Completed Courses", String.valueOf(completedCourses), Color.GREEN));
        statsPanel.add(createStatCard("Total Credits", String.valueOf(totalCredits), Color.ORANGE));
        statsPanel.add(createStatCard("Total Registrations", String.valueOf(registrations.size()), Color.MAGENTA));
        
        // Recent activity panel
        JPanel activityPanel = new JPanel(new BorderLayout());
        activityPanel.setBorder(BorderFactory.createTitledBorder("Recent Activity"));
        
        JTextArea activityArea = new JTextArea(8, 40);
        activityArea.setEditable(false);
        activityArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        StringBuilder activity = new StringBuilder();
        activity.append("Recent Course Activities:\n\n");
        
        registrations.stream().limit(5).forEach(reg -> {
            activity.append("• ").append(reg.getCourseCode())
                   .append(" - ").append(reg.getStatus())
                   .append(" (").append(reg.getRegistrationDate()).append(")\n");
        });
        
        if (registrations.isEmpty()) {
            activity.append("No course registrations yet.\n");
            activity.append("Visit the Course Registration tab to enroll in courses.");
        }
        
        activityArea.setText(activity.toString());
        activityPanel.add(new JScrollPane(activityArea), BorderLayout.CENTER);
        
        add(welcomePanel, BorderLayout.NORTH);
        add(statsPanel, BorderLayout.CENTER);
        add(activityPanel, BorderLayout.SOUTH);
    }
    
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel(title, JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(color);
        
        JLabel valueLabel = new JLabel(value, JLabel.CENTER);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(Color.BLACK);
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    private void setupLayout() {
        // Layout is already set in initializeComponents
    }
}