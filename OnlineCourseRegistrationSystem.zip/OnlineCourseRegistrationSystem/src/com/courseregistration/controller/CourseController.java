package com.courseregistration.controller;

import com.courseregistration.dao.CourseDAO;
import com.courseregistration.dao.PrerequisiteDAO;
import com.courseregistration.model.Course;

import javax.swing.*;
import java.util.Arrays;
import java.util.List;

public class CourseController {
    private CourseDAO courseDAO;
    private PrerequisiteDAO prerequisiteDAO;
    
    public CourseController() {
        this.courseDAO = new CourseDAO();
        this.prerequisiteDAO = new PrerequisiteDAO();
    }
    
    public boolean addCourse(String courseCode, String title, int credits, int capacity, 
                           String instructor, String scheduleTime, String scheduleDays, String location, String department, String prerequisites, String description) {
        if (validateCourseData(courseCode, title, credits, capacity)) {
            Course course = new Course();
            course.setCourseCode(courseCode);
            course.setTitle(title);
            course.setCredits(credits);
            course.setCapacity(capacity);
            course.setInstructorId(instructor);
            course.setScheduleTime(scheduleTime);
            course.setScheduleDays(scheduleDays);
            course.setLocation(location);
            course.setDepartment(department);
            course.setDescription(description);
            String result = courseDAO.insert(course);
            
            if ("SUCCESS".equals(result)) {
                // Handle prerequisites
                List<String> prereqList = parsePrerequisites(prerequisites);
                prerequisiteDAO.insertPrerequisites(courseCode, prereqList);
                
                JOptionPane.showMessageDialog(null, "Course added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add course:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        return false;
    }
    
    public boolean updateCourse(String courseCode, String title, int credits, int capacity, 
                              String instructor, String scheduleTime, String scheduleDays, String location, String department, String prerequisites, String description) {
        if (validateCourseData(courseCode, title, credits, capacity)) {
            Course course = new Course();
            course.setCourseCode(courseCode);
            course.setTitle(title);
            course.setCredits(credits);
            course.setCapacity(capacity);
            course.setInstructorId(instructor);
            course.setScheduleTime(scheduleTime);
            course.setScheduleDays(scheduleDays);
            course.setLocation(location);
            course.setDepartment(department);
            course.setDescription(description);
            boolean success = courseDAO.update(course);
            
            if (success) {
                // Handle prerequisites
                List<String> prereqList = parsePrerequisites(prerequisites);
                prerequisiteDAO.insertPrerequisites(courseCode, prereqList);
                
                JOptionPane.showMessageDialog(null, "Course updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to update course. Course might not exist.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            return success;
        }
        return false;
    }
    
    public boolean deleteCourse(String courseCode) {
        if (courseCode == null || courseCode.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a course to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to delete course: " + courseCode + "?", 
            "Confirm Delete", 
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = courseDAO.delete(courseCode);
            
            if (success) {
                JOptionPane.showMessageDialog(null, "Course deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to delete course.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            return success;
        }
        
        return false;
    }
    
    public List<Course> getAllCourses() {
        return courseDAO.getAll();
    }
    
    public Course getCourseById(String courseCode) {
        return courseDAO.getById(courseCode);
    }
    
    public Course getCourseByCode(String courseCode) {
        return courseDAO.getById(courseCode);
    }
    
    public List<Course> searchCourses(String courseCode, String title, String department) {
        return courseDAO.searchCourses(courseCode, title, department);
    }
    
    private boolean validateCourseData(String courseCode, String title, int credits, int capacity) {
        if (courseCode == null || courseCode.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Course code is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (title == null || title.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Course title is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (credits <= 0) {
            JOptionPane.showMessageDialog(null, "Credits must be greater than 0.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (capacity <= 0) {
            JOptionPane.showMessageDialog(null, "Capacity must be greater than 0.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    private List<String> parsePrerequisites(String prerequisites) {
        if (prerequisites == null || prerequisites.trim().isEmpty()) {
            return List.of();
        }
        return Arrays.asList(prerequisites.split(","))
                .stream()
                .map(String::trim)
                .filter(s -> !s.isEmpty())
                .toList();
    }
}