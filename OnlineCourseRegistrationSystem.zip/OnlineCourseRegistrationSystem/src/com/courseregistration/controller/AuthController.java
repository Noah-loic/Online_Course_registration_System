package com.courseregistration.controller;

import com.courseregistration.dao.UserDAO;
import com.courseregistration.model.User;
import com.courseregistration.util.DatabaseUtil;

import javax.swing.*;
import java.sql.*;

public class AuthController {
    private UserDAO userDAO;
    private User currentUser;
    
    public AuthController() {
        this.userDAO = new UserDAO();
    }
    
    public User login(String username, String password) {
        if (username == null || username.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Username is required.", "Login Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
        
        if (password == null || password.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Password is required.", "Login Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
        
        // Simple password hashing (in production, use proper hashing like BCrypt)
        String hashedPassword = simpleHash(password);
        
        User user = userDAO.authenticate(username, hashedPassword);
        
        if (user != null) {
            this.currentUser = user;
            JOptionPane.showMessageDialog(null, "Login successful! Welcome " + user.getUsername(), "Success", JOptionPane.INFORMATION_MESSAGE);
            return user;
        } else {
            JOptionPane.showMessageDialog(null, "Invalid username or password.", "Login Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }
    
    public boolean register(String userId, String username, String password, String email, String role) {
        if (!validateRegistrationData(userId, username, password, email, role)) {
            return false;
        }
        
        String hashedPassword = simpleHash(password);
        User user = new User(userId, username, hashedPassword, email, role);
        
        boolean success = userDAO.insert(user);
        
        if (success) {
            JOptionPane.showMessageDialog(null, "User registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registration failed. Username or email might already exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        return success;
    }
    
    public void logout() {
        this.currentUser = null;
        JOptionPane.showMessageDialog(null, "Logged out successfully.", "Logout", JOptionPane.INFORMATION_MESSAGE);
    }
    
    public User getCurrentUser() {
        return currentUser;
    }
    
    public boolean isLoggedIn() {
        return currentUser != null;
    }
    
    public boolean hasRole(String role) {
        return currentUser != null && role.equals(currentUser.getRole());
    }
    
    public boolean changePassword(String oldPassword, String newPassword) {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(null, "Please login first.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        String hashedOldPassword = simpleHash(oldPassword);
        if (!hashedOldPassword.equals(currentUser.getPassword())) {
            JOptionPane.showMessageDialog(null, "Current password is incorrect.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        String hashedNewPassword = simpleHash(newPassword);
        boolean success = userDAO.updatePassword(currentUser.getUserId(), hashedNewPassword);
        
        if (success) {
            currentUser.setPassword(hashedNewPassword);
            JOptionPane.showMessageDialog(null, "Password changed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Failed to change password.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        return success;
    }
    
    private boolean validateRegistrationData(String userId, String username, String password, String email, String role) {
        if (userId == null || userId.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "User ID is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (username == null || username.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Username is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (password == null || password.length() < 6) {
            JOptionPane.showMessageDialog(null, "Password must be at least 6 characters long.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (email == null || !email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(null, "Please enter a valid email address.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (role == null || role.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Role is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    public boolean registerExistingUser(String studentInstructorId, String username, String password) {
        // Check if student or instructor exists
        if (!checkStudentOrInstructorExists(studentInstructorId)) {
            JOptionPane.showMessageDialog(null, "Student/Instructor ID not found. Please contact admin.", "Registration Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Get email from student or instructor record
        String email = getEmailFromStudentOrInstructor(studentInstructorId);
        String role = determineRole(studentInstructorId);
        
        if (email == null || role == null) {
            JOptionPane.showMessageDialog(null, "Unable to retrieve user information.", "Registration Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        String hashedPassword = simpleHash(password);
        User user = new User(studentInstructorId, username, hashedPassword, email, role);
        
        boolean success = userDAO.insert(user);
        
        if (success) {
            JOptionPane.showMessageDialog(null, "Account registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Registration failed. Username might already exist.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        return success;
    }
    
    private boolean checkStudentOrInstructorExists(String id) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            // Check students table
            String studentSql = "SELECT COUNT(*) FROM students WHERE student_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(studentSql)) {
                stmt.setString(1, id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    return true;
                }
            }
            
            // Check instructors table
            String instructorSql = "SELECT COUNT(*) FROM instructors WHERE instructor_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(instructorSql)) {
                stmt.setString(1, id);
                ResultSet rs = stmt.executeQuery();
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            System.err.println("Error checking student/instructor existence: " + e.getMessage());
            return false;
        }
    }
    
    private String getEmailFromStudentOrInstructor(String id) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            // Check students table first
            String studentSql = "SELECT email FROM students WHERE student_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(studentSql)) {
                stmt.setString(1, id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getString("email");
                }
            }
            
            // Check instructors table
            String instructorSql = "SELECT email FROM instructors WHERE instructor_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(instructorSql)) {
                stmt.setString(1, id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    return rs.getString("email");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error getting email: " + e.getMessage());
        }
        return null;
    }
    
    private String determineRole(String id) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            // Check students table first
            String studentSql = "SELECT COUNT(*) FROM students WHERE student_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(studentSql)) {
                stmt.setString(1, id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    return "STUDENT";
                }
            }
            
            // Check instructors table
            String instructorSql = "SELECT COUNT(*) FROM instructors WHERE instructor_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(instructorSql)) {
                stmt.setString(1, id);
                ResultSet rs = stmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    return "INSTRUCTOR";
                }
            }
        } catch (SQLException e) {
            System.err.println("Error determining role: " + e.getMessage());
        }
        return null;
    }
    
    // Simple hash function (use proper hashing in production)
    private String simpleHash(String password) {
        // For demo purposes, return password as-is since database has plain text passwords
        return password;
    }
}