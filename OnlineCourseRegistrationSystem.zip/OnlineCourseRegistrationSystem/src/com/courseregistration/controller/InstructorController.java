package com.courseregistration.controller;

import com.courseregistration.dao.InstructorDAO;
import com.courseregistration.model.Instructor;

import java.util.List;

public class InstructorController {
    private InstructorDAO instructorDAO;
    
    public InstructorController() {
        this.instructorDAO = new InstructorDAO();
    }
    
    public List<Instructor> getAllInstructors() {
        return instructorDAO.getAll();
    }
    
    public Instructor getInstructorById(String instructorId) {
        return instructorDAO.getById(instructorId);
    }
}