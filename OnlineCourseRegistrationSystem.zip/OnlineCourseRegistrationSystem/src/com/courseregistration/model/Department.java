package com.courseregistration.model;

public class Department {
    private String deptId;
    private String deptName;
    private String officeLocation;
    
    public Department() {}
    
    public Department(String deptId, String deptName, String officeLocation) {
        this.deptId = deptId;
        this.deptName = deptName;
        this.officeLocation = officeLocation;
    }
    
    public String getDeptId() { return deptId; }
    public void setDeptId(String deptId) { this.deptId = deptId; }
    
    public String getDeptName() { return deptName; }
    public void setDeptName(String deptName) { this.deptName = deptName; }
    
    public String getOfficeLocation() { return officeLocation; }
    public void setOfficeLocation(String officeLocation) { this.officeLocation = officeLocation; }
}