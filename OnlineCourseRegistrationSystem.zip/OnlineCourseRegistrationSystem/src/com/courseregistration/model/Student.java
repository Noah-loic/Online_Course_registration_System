package com.courseregistration.model;

import java.time.LocalDateTime;

public class Student {
    private String studentId;
    private String name;
    private String email;
    private String phone;
    private String address;
    private int maxCredits;
    private int minCredits;
    private LocalDateTime createdAt;

    public Student() {
        this.maxCredits = 18;
        this.minCredits = 12;
    }

    public Student(String studentId, String name, String email, String phone, String address) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.maxCredits = 18;
        this.minCredits = 12;
    }

    // Getters and Setters
    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public int getMaxCredits() { return maxCredits; }
    public void setMaxCredits(int maxCredits) { this.maxCredits = maxCredits; }

    public int getMinCredits() { return minCredits; }
    public void setMinCredits(int minCredits) { this.minCredits = minCredits; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return "Student{" +
                "studentId='" + studentId + '\'' +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}