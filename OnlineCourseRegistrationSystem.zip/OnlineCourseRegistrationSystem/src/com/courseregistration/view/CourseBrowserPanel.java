package com.courseregistration.view;

import com.courseregistration.dao.CourseDAO;
import com.courseregistration.model.Course;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.List;

public class CourseBrowserPanel extends JPanel {
    private CourseDAO courseDAO;
    private JTextField txtSearchCode, txtSearchTitle, txtSearchInstructor;
    private JComboBox<String> cmbDepartment, cmbCredits;
    private JCheckBox chkAvailableOnly;
    private JTable courseTable;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> sorter;
    private JButton btnSearch, btnClear, btnAddToCart;
    private JTextArea txtCourseDetails;
    
    public CourseBrowserPanel() {
        courseDAO = new CourseDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadFilters();
        refreshTable();
    }
    
    private void initializeComponents() {
        // Search fields
        txtSearchCode = new JTextField(10);
        txtSearchTitle = new JTextField(15);
        txtSearchInstructor = new JTextField(15);
        
        // Filter combo boxes
        cmbDepartment = new JComboBox<>();
        cmbCredits = new JComboBox<>(new String[]{"Any", "1", "2", "3", "4", "5"});
        chkAvailableOnly = new JCheckBox("Available seats only", true);
        
        // Buttons
        btnSearch = new JButton("Search");
        btnClear = new JButton("Clear Filters");
        btnAddToCart = new JButton("Add to Cart");
        
        // Course details area
        txtCourseDetails = new JTextArea(6, 30);
        txtCourseDetails.setEditable(false);
        txtCourseDetails.setBorder(BorderFactory.createTitledBorder("Course Details"));
        
        // Table
        String[] columnNames = {"Code", "Title", "Credits", "Instructor", "Schedule", "Department", "Available", "Capacity", "Fee"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        courseTable = new JTable(tableModel);
        courseTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Add sorting capability
        sorter = new TableRowSorter<>(tableModel);
        courseTable.setRowSorter(sorter);
        
        courseTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                showCourseDetails();
            }
        });
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Search Panel
        JPanel searchPanel = new JPanel(new GridBagLayout());
        searchPanel.setBorder(BorderFactory.createTitledBorder("Course Search & Filters"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // First row
        gbc.gridx = 0; gbc.gridy = 0;
        searchPanel.add(new JLabel("Course Code:"), gbc);
        gbc.gridx = 1;
        searchPanel.add(txtSearchCode, gbc);
        
        gbc.gridx = 2;
        searchPanel.add(new JLabel("Title:"), gbc);
        gbc.gridx = 3;
        searchPanel.add(txtSearchTitle, gbc);
        
        gbc.gridx = 4;
        searchPanel.add(new JLabel("Instructor:"), gbc);
        gbc.gridx = 5;
        searchPanel.add(txtSearchInstructor, gbc);
        
        // Second row
        gbc.gridx = 0; gbc.gridy = 1;
        searchPanel.add(new JLabel("Department:"), gbc);
        gbc.gridx = 1;
        searchPanel.add(cmbDepartment, gbc);
        
        gbc.gridx = 2;
        searchPanel.add(new JLabel("Credits:"), gbc);
        gbc.gridx = 3;
        searchPanel.add(cmbCredits, gbc);
        
        gbc.gridx = 4; gbc.gridwidth = 2;
        searchPanel.add(chkAvailableOnly, gbc);
        
        // Button row
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 6;
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnSearch);
        buttonPanel.add(btnClear);
        buttonPanel.add(btnAddToCart);
        searchPanel.add(buttonPanel, gbc);
        
        // Main content panel
        JPanel contentPanel = new JPanel(new BorderLayout());
        
        // Table panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Available Courses"));
        tablePanel.add(new JScrollPane(courseTable), BorderLayout.CENTER);
        
        // Split pane for table and details
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setLeftComponent(tablePanel);
        splitPane.setRightComponent(new JScrollPane(txtCourseDetails));
        splitPane.setDividerLocation(600);
        
        contentPanel.add(splitPane, BorderLayout.CENTER);
        
        add(searchPanel, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnSearch.addActionListener(e -> performSearch());
        btnClear.addActionListener(e -> clearFilters());
        btnAddToCart.addActionListener(e -> addToCart());
        
        // Enter key search
        txtSearchCode.addActionListener(e -> performSearch());
        txtSearchTitle.addActionListener(e -> performSearch());
        txtSearchInstructor.addActionListener(e -> performSearch());
    }
    
    private void loadFilters() {
        // Load departments
        cmbDepartment.addItem("All Departments");
        List<Course> courses = courseDAO.getAll();
        courses.stream()
            .map(Course::getDepartment)
            .distinct()
            .sorted()
            .forEach(dept -> cmbDepartment.addItem(dept));
    }
    
    private void performSearch() {
        String codeFilter = txtSearchCode.getText().trim().toLowerCase();
        String titleFilter = txtSearchTitle.getText().trim().toLowerCase();
        String instructorFilter = txtSearchInstructor.getText().trim().toLowerCase();
        String deptFilter = (String) cmbDepartment.getSelectedItem();
        String creditsFilter = (String) cmbCredits.getSelectedItem();
        boolean availableOnly = chkAvailableOnly.isSelected();
        
        // Apply filters
        sorter.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                // Course code filter
                if (!codeFilter.isEmpty()) {
                    String code = entry.getStringValue(0).toLowerCase();
                    if (!code.contains(codeFilter)) return false;
                }
                
                // Title filter
                if (!titleFilter.isEmpty()) {
                    String title = entry.getStringValue(1).toLowerCase();
                    if (!title.contains(titleFilter)) return false;
                }
                
                // Instructor filter
                if (!instructorFilter.isEmpty()) {
                    String instructor = entry.getStringValue(3).toLowerCase();
                    if (!instructor.contains(instructorFilter)) return false;
                }
                
                // Department filter
                if (!"All Departments".equals(deptFilter)) {
                    String dept = entry.getStringValue(5);
                    if (!deptFilter.equals(dept)) return false;
                }
                
                // Credits filter
                if (!"Any".equals(creditsFilter)) {
                    String credits = entry.getStringValue(2);
                    if (!creditsFilter.equals(credits)) return false;
                }
                
                // Available seats filter
                if (availableOnly) {
                    String available = entry.getStringValue(6);
                    if ("0".equals(available)) return false;
                }
                
                return true;
            }
        });
    }
    
    private void clearFilters() {
        txtSearchCode.setText("");
        txtSearchTitle.setText("");
        txtSearchInstructor.setText("");
        cmbDepartment.setSelectedIndex(0);
        cmbCredits.setSelectedIndex(0);
        chkAvailableOnly.setSelected(true);
        sorter.setRowFilter(null);
    }
    
    private void addToCart() {
        int selectedRow = courseTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a course to add to cart.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Get course code from selected row
        int modelRow = courseTable.convertRowIndexToModel(selectedRow);
        String courseCode = (String) tableModel.getValueAt(modelRow, 0);
        
        // TODO: Implement cart functionality
        JOptionPane.showMessageDialog(this, "Course " + courseCode + " added to cart!", "Success", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void showCourseDetails() {
        int selectedRow = courseTable.getSelectedRow();
        if (selectedRow < 0) {
            txtCourseDetails.setText("");
            return;
        }
        
        int modelRow = courseTable.convertRowIndexToModel(selectedRow);
        String courseCode = (String) tableModel.getValueAt(modelRow, 0);
        
        // Get full course details
        Course course = courseDAO.getById(courseCode);
        if (course != null) {
            StringBuilder details = new StringBuilder();
            details.append("Course Code: ").append(course.getCourseCode()).append("\n");
            details.append("Title: ").append(course.getTitle()).append("\n");
            details.append("Credits: ").append(course.getCredits()).append("\n");
            details.append("Instructor: ").append(course.getInstructorName()).append("\n");
            details.append("Schedule: ").append(course.getScheduleDays()).append(" ").append(course.getScheduleTime()).append("\n");
            details.append("Department: ").append(course.getDepartment()).append("\n");
            details.append("Available Seats: ").append(course.getAvailableSeats()).append("/").append(course.getCapacity()).append("\n");
            details.append("Fee: $").append(course.getFee()).append("\n\n");
            details.append("Description:\n").append(course.getDescription() != null ? course.getDescription() : "No description available");
            
            txtCourseDetails.setText(details.toString());
        }
    }
    
    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Course> courses = courseDAO.getAll();
        
        for (Course course : courses) {
            String schedule = "";
            if (course.getScheduleDays() != null && course.getScheduleTime() != null) {
                schedule = course.getScheduleDays() + " " + course.getScheduleTime();
            } else if (course.getScheduleTime() != null) {
                schedule = course.getScheduleTime();
            } else {
                schedule = "TBD";
            }
            
            Object[] row = {
                course.getCourseCode(),
                course.getTitle(),
                course.getCredits(),
                course.getInstructorName() != null ? course.getInstructorName() : "TBD",
                schedule,
                course.getDepartment() != null ? course.getDepartment() : "TBD",
                course.getAvailableSeats(),
                course.getCapacity(),
                "$" + (course.getFee() != null ? course.getFee() : "0.00")
            };
            tableModel.addRow(row);
        }
    }
}