package com.courseregistration.view;

import com.courseregistration.dao.WaitlistDAO;
import com.courseregistration.dao.CourseDAO;
import com.courseregistration.model.Waitlist;
import com.courseregistration.model.Course;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class WaitlistPanel extends JPanel {
    private WaitlistDAO waitlistDAO;
    private CourseDAO courseDAO;
    private JComboBox<String> cmbCourseCode;
    private JTable waitlistTable;
    private DefaultTableModel tableModel;
    private JButton btnRefresh, btnRemoveFromWaitlist, btnPromoteStudent;
    
    public WaitlistPanel() {
        waitlistDAO = new WaitlistDAO();
        courseDAO = new CourseDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadCourses();
        refreshTable();
    }
    
    private void initializeComponents() {
        // Combo box for course selection
        cmbCourseCode = new JComboBox<>();
        
        // Buttons
        btnRefresh = new JButton("Refresh");
        btnRemoveFromWaitlist = new JButton("Remove from Waitlist");
        btnPromoteStudent = new JButton("Promote to Registration");
        
        // Table
        String[] columnNames = {"Waitlist ID", "Position", "Student ID", "Student Name", "Course Code", "Course Title", "Date Added", "Notified"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        waitlistTable = new JTable(tableModel);
        waitlistTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Filter Panel
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterPanel.setBorder(BorderFactory.createTitledBorder("Filter by Course"));
        filterPanel.add(new JLabel("Course:"));
        filterPanel.add(cmbCourseCode);
        filterPanel.add(btnRefresh);
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnRemoveFromWaitlist);
        buttonPanel.add(btnPromoteStudent);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Waitlist Entries"));
        tablePanel.add(new JScrollPane(waitlistTable), BorderLayout.CENTER);
        tablePanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(filterPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnRefresh.addActionListener(e -> refreshTable());
        btnRemoveFromWaitlist.addActionListener(e -> removeFromWaitlist());
        btnPromoteStudent.addActionListener(e -> promoteStudent());
        
        cmbCourseCode.addActionListener(e -> refreshTable());
    }
    
    private void loadCourses() {
        cmbCourseCode.removeAllItems();
        cmbCourseCode.addItem("All Courses");
        
        List<Course> courses = courseDAO.getAll();
        for (Course course : courses) {
            cmbCourseCode.addItem(course.getCourseCode() + " - " + course.getTitle());
        }
    }
    
    private void refreshTable() {
        tableModel.setRowCount(0);
        
        String selectedCourse = (String) cmbCourseCode.getSelectedItem();
        List<Waitlist> waitlistEntries;
        
        if ("All Courses".equals(selectedCourse)) {
            // Get all waitlist entries (would need to implement in DAO)
            waitlistEntries = getAllWaitlistEntries();
        } else {
            String courseCode = selectedCourse.split(" - ")[0];
            waitlistEntries = waitlistDAO.getByCourseCode(courseCode);
        }
        
        for (Waitlist entry : waitlistEntries) {
            Object[] row = {
                entry.getWaitlistId(),
                entry.getPosition(),
                entry.getStudentId(),
                entry.getStudentName(),
                entry.getCourseCode(),
                entry.getCourseTitle(),
                entry.getWaitlistDate(),
                entry.isNotified() ? "Yes" : "No"
            };
            tableModel.addRow(row);
        }
    }
    
    private void removeFromWaitlist() {
        int selectedRow = waitlistTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a waitlist entry to remove.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int waitlistId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String studentName = (String) tableModel.getValueAt(selectedRow, 3);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to remove " + studentName + " from the waitlist?",
            "Confirm Removal",
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            if (waitlistDAO.delete(waitlistId)) {
                JOptionPane.showMessageDialog(this, "Student removed from waitlist successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to remove student from waitlist.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private void promoteStudent() {
        int selectedRow = waitlistTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a waitlist entry to promote.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String studentId = (String) tableModel.getValueAt(selectedRow, 2);
        String courseCode = (String) tableModel.getValueAt(selectedRow, 4);
        String studentName = (String) tableModel.getValueAt(selectedRow, 3);
        
        int confirm = JOptionPane.showConfirmDialog(this,
            "Promote " + studentName + " to regular registration for " + courseCode + "?",
            "Confirm Promotion",
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            // This would typically involve:
            // 1. Creating a new registration
            // 2. Removing from waitlist
            // 3. Sending notification
            // For now, just show a message
            JOptionPane.showMessageDialog(this, 
                "Student promotion functionality would be implemented here.\n" +
                "This would create a registration and remove from waitlist.", 
                "Feature Note", 
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private List<Waitlist> getAllWaitlistEntries() {
        // This would need to be implemented in WaitlistDAO
        // For now, return empty list
        return java.util.Collections.emptyList();
    }
}