package com.courseregistration.dao;

import com.courseregistration.model.Department;
import com.courseregistration.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DepartmentDAO {
    
    public List<Department> getAll() {
        List<Department> departments = new ArrayList<>();
        String sql = "SELECT * FROM departments ORDER BY dept_id";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Department dept = new Department();
                dept.setDeptId(rs.getString("dept_id"));
                dept.setDeptName(rs.getString("dept_name"));
                dept.setOfficeLocation(rs.getString("office_location"));
                departments.add(dept);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving departments: " + e.getMessage());
        }
        
        return departments;
    }
    
    public String insert(Department department) {
        String sql = "INSERT INTO departments (dept_id, dept_name, office_location) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, department.getDeptId());
            stmt.setString(2, department.getDeptName());
            stmt.setString(3, department.getOfficeLocation());
            
            return stmt.executeUpdate() > 0 ? "SUCCESS" : "Failed to insert department";
            
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) {
                return "Department ID already exists";
            }
            return "Database error: " + e.getMessage();
        }
    }
    
    public String update(Department department) {
        String sql = "UPDATE departments SET dept_name = ?, office_location = ? WHERE dept_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, department.getDeptName());
            stmt.setString(2, department.getOfficeLocation());
            stmt.setString(3, department.getDeptId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0 ? "SUCCESS" : "Department not found";
            
        } catch (SQLException e) {
            return "Database error: " + e.getMessage();
        }
    }
    
    public String delete(String deptId) {
        String sql = "DELETE FROM departments WHERE dept_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, deptId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0 ? "SUCCESS" : "Department not found";
            
        } catch (SQLException e) {
            if (e.getErrorCode() == 1451) {
                return "Cannot delete department: It has associated courses or instructors";
            }
            return "Database error: " + e.getMessage();
        }
    }
}