package com.courseregistration.dao;

import com.courseregistration.model.Course;
import com.courseregistration.model.Registration;
import com.courseregistration.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RegistrationDAO {
    
    public String registerStudent(String studentId, String courseCode) {
        try (Connection conn = DatabaseUtil.getConnection()) {
            // Check if already registered
            if (isAlreadyRegistered(studentId, courseCode)) {
                return "Already registered for this course";
            }
            
            // Check course capacity
            if (isCourseAtCapacity(courseCode)) {
                return "Course is at full capacity";
            }
            
            String sql = "INSERT INTO registrations (student_id, course_code, registration_date, status) VALUES (?, ?, CURDATE(), 'ACTIVE')";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, studentId);
                stmt.setString(2, courseCode);
                
                int result = stmt.executeUpdate();
                if (result > 0) {
                    updateEnrolledCount(courseCode);
                    return "SUCCESS";
                }
                return "Failed to register for course";
            }
            
        } catch (SQLException e) {
            if (e.getErrorCode() == 1452) {
                return "Invalid student ID or course code";
            }
            return "Database error: " + e.getMessage();
        }
    }
    
    public String dropCourse(String studentId, String courseCode) {
        String sql = "UPDATE registrations SET status = 'DROPPED' WHERE student_id = ? AND course_code = ? AND status = 'ACTIVE'";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, studentId);
            stmt.setString(2, courseCode);
            
            int result = stmt.executeUpdate();
            if (result > 0) {
                updateEnrolledCount(courseCode);
                return "SUCCESS";
            }
            return "Course not found or already dropped";
            
        } catch (SQLException e) {
            return "Database error: " + e.getMessage();
        }
    }
    
    public List<Course> getStudentCourses(String studentId) {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT c.*, i.name as instructor_name FROM registrations r " +
                    "JOIN courses c ON r.course_code = c.course_code " +
                    "LEFT JOIN instructors i ON c.instructor_id = i.instructor_id " +
                    "WHERE r.student_id = ? AND r.status = 'ACTIVE'";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, studentId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Course course = new Course();
                course.setCourseCode(rs.getString("course_code"));
                course.setTitle(rs.getString("title"));
                course.setCredits(rs.getInt("credits"));
                course.setInstructorName(rs.getString("instructor_name"));
                course.setScheduleTime(rs.getString("schedule_time"));
                course.setScheduleDays(rs.getString("schedule_days"));
                course.setLocation(rs.getString("location"));
                courses.add(course);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving student courses: " + e.getMessage());
        }
        
        return courses;
    }
    
    private boolean isAlreadyRegistered(String studentId, String courseCode) {
        String sql = "SELECT COUNT(*) FROM registrations WHERE student_id = ? AND course_code = ? AND status IN ('ACTIVE', 'PENDING', 'COMPLETED')";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, studentId);
            stmt.setString(2, courseCode);
            ResultSet rs = stmt.executeQuery();
            
            return rs.next() && rs.getInt(1) > 0;
            
        } catch (SQLException e) {
            return false;
        }
    }
    
    private boolean isCourseAtCapacity(String courseCode) {
        String sql = "SELECT capacity, enrolled_count FROM courses WHERE course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                int capacity = rs.getInt("capacity");
                int enrolled = rs.getInt("enrolled_count");
                return enrolled >= capacity;
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking course capacity: " + e.getMessage());
        }
        
        return true; // Assume at capacity if error
    }
    
    private void updateEnrolledCount(String courseCode) {
        String sql = "UPDATE courses SET enrolled_count = (SELECT COUNT(*) FROM registrations WHERE course_code = ? AND status = 'ACTIVE') WHERE course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            stmt.setString(2, courseCode);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error updating enrolled count: " + e.getMessage());
        }
    }
    
    public boolean isStudentRegistered(String studentId, String courseCode) {
        return isAlreadyRegistered(studentId, courseCode);
    }
    
    public boolean insert(Registration registration) {
        String sql = "INSERT INTO registrations (student_id, course_code, registration_date, status) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, registration.getStudentId());
            stmt.setString(2, registration.getCourseCode());
            stmt.setDate(3, Date.valueOf(registration.getRegistrationDate()));
            stmt.setString(4, registration.getStatus());
            
            boolean success = stmt.executeUpdate() > 0;
            if (success && "ACTIVE".equals(registration.getStatus())) {
                updateEnrolledCount(registration.getCourseCode());
            }
            return success;
            
        } catch (SQLException e) {
            System.err.println("Error inserting registration: " + e.getMessage());
            return false;
        }
    }
    
    public boolean update(Registration registration) {
        String sql = "UPDATE registrations SET status = ?, grade = ? WHERE registration_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, registration.getStatus());
            stmt.setString(2, registration.getGrade());
            stmt.setInt(3, registration.getRegistrationId());
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating registration: " + e.getMessage());
            return false;
        }
    }
    
    public boolean delete(int registrationId) {
        String sql = "DELETE FROM registrations WHERE registration_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, registrationId);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting registration: " + e.getMessage());
            return false;
        }
    }
    
    public List<Registration> getAll() {
        List<Registration> registrations = new ArrayList<>();
        String sql = "SELECT r.*, s.name as student_name, c.title as course_title " +
                    "FROM registrations r " +
                    "LEFT JOIN students s ON r.student_id = s.student_id " +
                    "LEFT JOIN courses c ON r.course_code = c.course_code " +
                    "ORDER BY r.registration_date DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Registration registration = new Registration();
                registration.setRegistrationId(rs.getInt("registration_id"));
                registration.setStudentId(rs.getString("student_id"));
                registration.setCourseCode(rs.getString("course_code"));
                registration.setRegistrationDate(rs.getDate("registration_date").toLocalDate());
                registration.setStatus(rs.getString("status"));
                registration.setGrade(rs.getString("grade"));
                registration.setStudentName(rs.getString("student_name"));
                registration.setCourseTitle(rs.getString("course_title"));
                registrations.add(registration);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving registrations: " + e.getMessage());
        }
        
        return registrations;
    }
    
    public List<Registration> searchRegistrations(String courseCode, String studentId, String grade) {
        List<Registration> registrations = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT r.*, s.name as student_name, c.title as course_title " +
            "FROM registrations r " +
            "LEFT JOIN students s ON r.student_id = s.student_id " +
            "LEFT JOIN courses c ON r.course_code = c.course_code WHERE 1=1");
        
        List<String> params = new ArrayList<>();
        
        if (courseCode != null && !courseCode.trim().isEmpty()) {
            sql.append(" AND r.course_code LIKE ?");
            params.add("%" + courseCode.trim() + "%");
        }
        
        if (studentId != null && !studentId.trim().isEmpty()) {
            sql.append(" AND (r.student_id LIKE ? OR s.name LIKE ?)");
            params.add("%" + studentId.trim() + "%");
            params.add("%" + studentId.trim() + "%");
        }
        
        if (grade != null && !grade.trim().isEmpty()) {
            sql.append(" AND r.grade LIKE ?");
            params.add("%" + grade.trim() + "%");
        }
        
        sql.append(" ORDER BY r.registration_date DESC");
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                stmt.setString(i + 1, params.get(i));
            }
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Registration registration = new Registration();
                registration.setRegistrationId(rs.getInt("registration_id"));
                registration.setStudentId(rs.getString("student_id"));
                registration.setCourseCode(rs.getString("course_code"));
                registration.setRegistrationDate(rs.getDate("registration_date").toLocalDate());
                registration.setStatus(rs.getString("status"));
                registration.setGrade(rs.getString("grade"));
                registration.setStudentName(rs.getString("student_name"));
                registration.setCourseTitle(rs.getString("course_title"));
                registrations.add(registration);
            }
            
        } catch (SQLException e) {
            System.err.println("Error searching registrations: " + e.getMessage());
        }
        
        return registrations;
    }
    
    public List<Registration> getByStudentId(String studentId) {
        List<Registration> registrations = new ArrayList<>();
        String sql = "SELECT * FROM registrations WHERE student_id = ? ORDER BY registration_date DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, studentId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Registration registration = new Registration();
                registration.setRegistrationId(rs.getInt("registration_id"));
                registration.setStudentId(rs.getString("student_id"));
                registration.setCourseCode(rs.getString("course_code"));
                registration.setRegistrationDate(rs.getDate("registration_date").toLocalDate());
                registration.setStatus(rs.getString("status"));
                registration.setGrade(rs.getString("grade"));
                registrations.add(registration);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving student registrations: " + e.getMessage());
        }
        
        return registrations;
    }
    
    public List<Registration> getByCourseCode(String courseCode) {
        List<Registration> registrations = new ArrayList<>();
        String sql = "SELECT r.*, s.name as student_name FROM registrations r " +
                    "JOIN students s ON r.student_id = s.student_id " +
                    "WHERE r.course_code = ? AND r.status = 'ACTIVE' " +
                    "ORDER BY r.registration_date DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Registration registration = new Registration();
                registration.setRegistrationId(rs.getInt("registration_id"));
                registration.setStudentId(rs.getString("student_id"));
                registration.setCourseCode(rs.getString("course_code"));
                registration.setRegistrationDate(rs.getDate("registration_date").toLocalDate());
                registration.setStatus(rs.getString("status"));
                registration.setGrade(rs.getString("grade"));
                registration.setStudentName(rs.getString("student_name"));
                registrations.add(registration);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving course registrations: " + e.getMessage());
        }
        
        return registrations;
    }
    
    public boolean updateGradeAndStatus(String studentId, String courseCode, String grade, String status) {
        String sql = "UPDATE registrations SET grade = ?, status = ? WHERE student_id = ? AND course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, grade);
            stmt.setString(2, status);
            stmt.setString(3, studentId);
            stmt.setString(4, courseCode);
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating grade and status: " + e.getMessage());
            return false;
        }
    }
}