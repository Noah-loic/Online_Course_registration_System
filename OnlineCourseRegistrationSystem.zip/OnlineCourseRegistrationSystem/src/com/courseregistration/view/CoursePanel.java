package com.courseregistration.view;

import com.courseregistration.controller.CourseController;
import com.courseregistration.model.Course;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class CoursePanel extends JPanel {
    private CourseController courseController;
    private JTextField txtCourseCode, txtTitle, txtCredits, txtCapacity, txtInstructor, txtScheduleTime, txtScheduleDays, txtLocation, txtDepartment, txtPrerequisites;
    private JTextArea txtDescription;
    private JTable courseTable;
    private DefaultTableModel tableModel;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh, btnClear;
    
    // Search components
    private JTextField txtSearchCode, txtSearchTitle, txtSearchDepartment;
    private JButton btnSearch, btnClearSearch;
    
    public CoursePanel() {
        courseController = new CourseController();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        refreshTable();
    }
    
    private void initializeComponents() {
        // Input fields
        txtCourseCode = new JTextField(10);
        txtTitle = new JTextField(25);
        txtCredits = new JTextField(5);
        txtCapacity = new JTextField(5);
        txtInstructor = new JTextField(20);
        txtScheduleTime = new JTextField(15);
        txtScheduleDays = new JTextField(15);
        txtLocation = new JTextField(15);
        txtDepartment = new JTextField(15);
        txtPrerequisites = new JTextField(20);
        txtDescription = new JTextArea(3, 25);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        
        // Buttons
        btnAdd = new JButton("Add Course");
        btnUpdate = new JButton("Update Course");
        btnDelete = new JButton("Delete Course");
        btnRefresh = new JButton("Refresh");
        btnClear = new JButton("Clear");
        
        // Search components
        txtSearchCode = new JTextField(10);
        txtSearchTitle = new JTextField(15);
        txtSearchDepartment = new JTextField(15);
        btnSearch = new JButton("Search");
        btnClearSearch = new JButton("Clear Search");
        
        // Table
        String[] columnNames = {"Course Code", "Title", "Credits", "Capacity", "Instructor", "Schedule", "Days", "Location", "Department"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        courseTable = new JTable(tableModel);
        courseTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        courseTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedCourse();
            }
        });
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Course Information"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Course Code
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(new JLabel("Course Code:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtCourseCode, gbc);
        
        // Title
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Title:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtTitle, gbc);
        
        // Credits
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Credits:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtCredits, gbc);
        
        // Capacity
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Capacity:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtCapacity, gbc);
        
        // Instructor
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Instructor:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtInstructor, gbc);
        
        // Schedule Time
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Schedule:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtScheduleTime, gbc);
        
        // Schedule Days
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Days:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtScheduleDays, gbc);
        
        // Location
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Location:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtLocation, gbc);
        
        // Department
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Department:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtDepartment, gbc);
        
        // Prerequisites
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Prerequisites:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtPrerequisites, gbc);
        
        // Description
        gbc.gridx = 0; gbc.gridy = 6; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Description:"), gbc);
        gbc.gridx = 1; gbc.gridwidth = 3; gbc.fill = GridBagConstraints.BOTH;
        formPanel.add(new JScrollPane(txtDescription), gbc);
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnClear);
        
        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search Courses"));
        searchPanel.add(new JLabel("Code:"));
        searchPanel.add(txtSearchCode);
        searchPanel.add(new JLabel("Title:"));
        searchPanel.add(txtSearchTitle);
        searchPanel.add(new JLabel("Department:"));
        searchPanel.add(txtSearchDepartment);
        searchPanel.add(btnSearch);
        searchPanel.add(btnClearSearch);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Courses List"));
        tablePanel.add(searchPanel, BorderLayout.NORTH);
        tablePanel.add(new JScrollPane(courseTable), BorderLayout.CENTER);
        
        // Main layout
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(formPanel, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(topPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnAdd.addActionListener(e -> addCourse());
        btnUpdate.addActionListener(e -> updateCourse());
        btnDelete.addActionListener(e -> deleteCourse());
        btnRefresh.addActionListener(e -> refreshTable());
        btnClear.addActionListener(e -> clearFields());
        btnSearch.addActionListener(e -> searchCourses());
        btnClearSearch.addActionListener(e -> clearSearch());
    }
    
    private void addCourse() {
        try {
            String courseCode = txtCourseCode.getText().trim();
            String title = txtTitle.getText().trim();
            int credits = Integer.parseInt(txtCredits.getText().trim());
            int capacity = Integer.parseInt(txtCapacity.getText().trim());
            String instructor = txtInstructor.getText().trim();
            String scheduleTime = txtScheduleTime.getText().trim();
            String scheduleDays = txtScheduleDays.getText().trim();
            String location = txtLocation.getText().trim();
            String department = txtDepartment.getText().trim();
            String prerequisites = txtPrerequisites.getText().trim();
            String description = txtDescription.getText().trim();
            
            if (courseController.addCourse(courseCode, title, credits, capacity, instructor, scheduleTime, scheduleDays, location, department, prerequisites, description)) {
                clearFields();
                refreshTable();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for credits and capacity.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateCourse() {
        try {
            String courseCode = txtCourseCode.getText().trim();
            String title = txtTitle.getText().trim();
            int credits = Integer.parseInt(txtCredits.getText().trim());
            int capacity = Integer.parseInt(txtCapacity.getText().trim());
            String instructor = txtInstructor.getText().trim();
            String scheduleTime = txtScheduleTime.getText().trim();
            String scheduleDays = txtScheduleDays.getText().trim();
            String location = txtLocation.getText().trim();
            String department = txtDepartment.getText().trim();
            String prerequisites = txtPrerequisites.getText().trim();
            String description = txtDescription.getText().trim();
            
            if (courseController.updateCourse(courseCode, title, credits, capacity, instructor, scheduleTime, scheduleDays, location, department, prerequisites, description)) {
                clearFields();
                refreshTable();
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for credits and capacity.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteCourse() {
        String courseCode = txtCourseCode.getText().trim();
        if (courseController.deleteCourse(courseCode)) {
            clearFields();
            refreshTable();
        }
    }
    
    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Course> courses = courseController.getAllCourses();
        
        for (Course course : courses) {
            Object[] row = {
                course.getCourseCode(),
                course.getTitle(),
                course.getCredits(),
                course.getCapacity(),
                course.getInstructorName(),
                course.getScheduleTime(),
                course.getScheduleDays(),
                course.getLocation(),
                course.getDepartment()
            };
            tableModel.addRow(row);
        }
    }
    
    private void loadSelectedCourse() {
        int selectedRow = courseTable.getSelectedRow();
        if (selectedRow >= 0) {
            txtCourseCode.setText((String) tableModel.getValueAt(selectedRow, 0));
            txtTitle.setText((String) tableModel.getValueAt(selectedRow, 1));
            txtCredits.setText(String.valueOf(tableModel.getValueAt(selectedRow, 2)));
            txtCapacity.setText(String.valueOf(tableModel.getValueAt(selectedRow, 3)));
            txtInstructor.setText((String) tableModel.getValueAt(selectedRow, 4));
            txtScheduleTime.setText((String) tableModel.getValueAt(selectedRow, 5));
            txtScheduleDays.setText((String) tableModel.getValueAt(selectedRow, 6));
            txtLocation.setText((String) tableModel.getValueAt(selectedRow, 7));
            txtDepartment.setText((String) tableModel.getValueAt(selectedRow, 8));
            
            // Load additional data from database
            Course course = courseController.getCourseById((String) tableModel.getValueAt(selectedRow, 0));
            if (course != null) {
                txtDescription.setText(course.getDescription());
                if (course.getPrerequisites() != null && !course.getPrerequisites().isEmpty()) {
                    txtPrerequisites.setText(String.join(", ", course.getPrerequisites()));
                } else {
                    txtPrerequisites.setText("");
                }
            }
        }
    }
    
    private void clearFields() {
        txtCourseCode.setText("");
        txtTitle.setText("");
        txtCredits.setText("");
        txtCapacity.setText("");
        txtInstructor.setText("");
        txtScheduleTime.setText("");
        txtScheduleDays.setText("");
        txtLocation.setText("");
        txtDepartment.setText("");
        txtPrerequisites.setText("");
        txtDescription.setText("");
        courseTable.clearSelection();
    }
    
    private void searchCourses() {
        String courseCode = txtSearchCode.getText().trim();
        String title = txtSearchTitle.getText().trim();
        String department = txtSearchDepartment.getText().trim();
        
        tableModel.setRowCount(0);
        List<Course> courses = courseController.searchCourses(courseCode, title, department);
        
        for (Course course : courses) {
            Object[] row = {
                course.getCourseCode(),
                course.getTitle(),
                course.getCredits(),
                course.getCapacity(),
                course.getInstructorName(),
                course.getScheduleTime(),
                course.getScheduleDays(),
                course.getLocation(),
                course.getDepartment()
            };
            tableModel.addRow(row);
        }
    }
    
    private void clearSearch() {
        txtSearchCode.setText("");
        txtSearchTitle.setText("");
        txtSearchDepartment.setText("");
        refreshTable();
    }
}