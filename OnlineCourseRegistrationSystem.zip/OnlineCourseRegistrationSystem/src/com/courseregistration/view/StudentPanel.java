package com.courseregistration.view;

import com.courseregistration.controller.StudentController;
import com.courseregistration.model.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class StudentPanel extends JPanel {
    private StudentController studentController;
    private JTextField txtStudentId, txtName, txtEmail, txtPhone;
    private JTextArea txtAddress;
    private JTable studentTable;
    private DefaultTableModel tableModel;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh, btnClear;
    
    // Search components
    private JTextField txtSearchId, txtSearchName, txtSearchEmail;
    private JButton btnSearch, btnClearSearch;
    
    public StudentPanel() {
        studentController = new StudentController();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        refreshTable();
    }
    
    private void initializeComponents() {
        // Input fields
        txtStudentId = new JTextField(15);
        txtName = new JTextField(20);
        txtEmail = new JTextField(20);
        txtPhone = new JTextField(15);
        txtAddress = new JTextArea(3, 20);
        txtAddress.setLineWrap(true);
        txtAddress.setWrapStyleWord(true);
        
        // Buttons
        btnAdd = new JButton("Add Student");
        btnUpdate = new JButton("Update Student");
        btnDelete = new JButton("Delete Student");
        btnRefresh = new JButton("Refresh");
        btnClear = new JButton("Clear");
        
        // Search components
        txtSearchId = new JTextField(10);
        txtSearchName = new JTextField(15);
        txtSearchEmail = new JTextField(15);
        btnSearch = new JButton("Search");
        btnClearSearch = new JButton("Clear Search");
        
        // Table
        String[] columnNames = {"Student ID", "Name", "Email", "Phone", "Address"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        studentTable = new JTable(tableModel);
        studentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedStudent();
            }
        });
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Student Information"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Student ID
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(new JLabel("Student ID:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtStudentId, gbc);
        
        // Name
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtName, gbc);
        
        // Email
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtEmail, gbc);
        
        // Phone
        gbc.gridx = 0; gbc.gridy = 3; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtPhone, gbc);
        
        // Address
        gbc.gridx = 0; gbc.gridy = 4; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Address:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.BOTH;
        formPanel.add(new JScrollPane(txtAddress), gbc);
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnClear);
        
        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search Students"));
        searchPanel.add(new JLabel("ID:"));
        searchPanel.add(txtSearchId);
        searchPanel.add(new JLabel("Name:"));
        searchPanel.add(txtSearchName);
        searchPanel.add(new JLabel("Email:"));
        searchPanel.add(txtSearchEmail);
        searchPanel.add(btnSearch);
        searchPanel.add(btnClearSearch);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Students List"));
        tablePanel.add(searchPanel, BorderLayout.NORTH);
        tablePanel.add(new JScrollPane(studentTable), BorderLayout.CENTER);
        
        // Main layout
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(formPanel, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(topPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnAdd.addActionListener(e -> addStudent());
        btnUpdate.addActionListener(e -> updateStudent());
        btnDelete.addActionListener(e -> deleteStudent());
        btnRefresh.addActionListener(e -> refreshTable());
        btnClear.addActionListener(e -> clearFields());
        btnSearch.addActionListener(e -> searchStudents());
        btnClearSearch.addActionListener(e -> clearSearch());
    }
    
    private void addStudent() {
        String studentId = txtStudentId.getText().trim();
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String address = txtAddress.getText().trim();
        
        if (studentController.addStudent(studentId, name, email, phone, address)) {
            clearFields();
            refreshTable();
        }
    }
    
    private void updateStudent() {
        String studentId = txtStudentId.getText().trim();
        String name = txtName.getText().trim();
        String email = txtEmail.getText().trim();
        String phone = txtPhone.getText().trim();
        String address = txtAddress.getText().trim();
        
        if (studentController.updateStudent(studentId, name, email, phone, address)) {
            clearFields();
            refreshTable();
        }
    }
    
    private void deleteStudent() {
        String studentId = txtStudentId.getText().trim();
        if (studentController.deleteStudent(studentId)) {
            clearFields();
            refreshTable();
        }
    }
    
    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Student> students = studentController.getAllStudents();
        
        for (Student student : students) {
            Object[] row = {
                student.getStudentId(),
                student.getName(),
                student.getEmail(),
                student.getPhone(),
                student.getAddress()
            };
            tableModel.addRow(row);
        }
    }
    
    private void loadSelectedStudent() {
        int selectedRow = studentTable.getSelectedRow();
        if (selectedRow >= 0) {
            txtStudentId.setText((String) tableModel.getValueAt(selectedRow, 0));
            txtName.setText((String) tableModel.getValueAt(selectedRow, 1));
            txtEmail.setText((String) tableModel.getValueAt(selectedRow, 2));
            txtPhone.setText((String) tableModel.getValueAt(selectedRow, 3));
            txtAddress.setText((String) tableModel.getValueAt(selectedRow, 4));
        }
    }
    
    private void clearFields() {
        txtStudentId.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtAddress.setText("");
        studentTable.clearSelection();
    }
    
    private void searchStudents() {
        String studentId = txtSearchId.getText().trim();
        String name = txtSearchName.getText().trim();
        String email = txtSearchEmail.getText().trim();
        
        tableModel.setRowCount(0);
        List<Student> students = studentController.searchStudents(studentId, name, email);
        
        for (Student student : students) {
            Object[] row = {
                student.getStudentId(),
                student.getName(),
                student.getEmail(),
                student.getPhone(),
                student.getAddress()
            };
            tableModel.addRow(row);
        }
    }
    
    private void clearSearch() {
        txtSearchId.setText("");
        txtSearchName.setText("");
        txtSearchEmail.setText("");
        refreshTable();
    }
}