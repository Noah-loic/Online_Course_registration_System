package com.courseregistration.view;

import com.courseregistration.controller.*;
import com.courseregistration.dao.RegistrationDAO;
import com.courseregistration.model.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class InstructorDashboardPanel extends JPanel {
    private CourseController courseController;
    private RegistrationController registrationController;
    private User currentUser;
    
    public InstructorDashboardPanel(User currentUser) {
        this.currentUser = currentUser;
        courseController = new CourseController();
        registrationController = new RegistrationController();
        
        initializeComponents();
        setupLayout();
    }
    
    private void initializeComponents() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Welcome panel
        JPanel welcomePanel = new JPanel();
        JLabel welcomeLabel = new JLabel("Welcome, " + currentUser.getUsername() + "!");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomePanel.add(welcomeLabel);
        
        // Stats panel
        JPanel statsPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        
        // Get instructor courses (match by userId which maps to instructor_id in DB)
        List<Course> allCourses = courseController.getAllCourses();
        List<Course> instructorCourses = allCourses.stream()
            .filter(c -> currentUser.getUserId() != null && currentUser.getUserId().equals(c.getInstructorId()))
            .toList();

        // Use RegistrationDAO to count only ACTIVE registrations per course
        RegistrationDAO registrationDAOLocal = new RegistrationDAO();
        int totalStudents = instructorCourses.stream()
            .mapToInt(c -> registrationDAOLocal.getByCourseCode(c.getCourseCode()).size())
            .sum();

        // Calculate average enrollment (based on active students)
        double avgEnrollment = instructorCourses.isEmpty() ? 0 :
            (double) totalStudents / instructorCourses.size();
        
        statsPanel.add(createStatCard("My Courses", String.valueOf(instructorCourses.size()), Color.BLUE));
        statsPanel.add(createStatCard("Total Students", String.valueOf(totalStudents), Color.GREEN));
        statsPanel.add(createStatCard("Avg Enrollment", String.format("%.1f", avgEnrollment), Color.ORANGE));
        long activeCourses = instructorCourses.stream().filter(Course::isActive).count();
        statsPanel.add(createStatCard("Active Courses", String.valueOf(activeCourses), Color.MAGENTA));
        
        // Course overview panel
        JPanel coursePanel = new JPanel(new BorderLayout());
        coursePanel.setBorder(BorderFactory.createTitledBorder("My Courses Overview"));
        
        JTextArea courseArea = new JTextArea(8, 40);
        courseArea.setEditable(false);
        courseArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        StringBuilder courseInfo = new StringBuilder();
        courseInfo.append("Course Details:\n\n");
        
        if (instructorCourses.isEmpty()) {
            courseInfo.append("No courses assigned yet.\n");
            courseInfo.append("Contact the administrator for course assignments.");
        } else {
            for (Course course : instructorCourses) {
                int activeEnrolled = registrationDAOLocal.getByCourseCode(course.getCourseCode()).size();
                courseInfo.append("• ").append(course.getCourseCode())
                         .append(" - ").append(course.getTitle())
                         .append("\n  Enrolled: ").append(activeEnrolled)
                         .append("/").append(course.getCapacity())
                         .append(" | Credits: ").append(course.getCredits())
                         .append("\n  Schedule: ").append(course.getScheduleDays())
                         .append(" ").append(course.getScheduleTime())
                         .append("\n\n");
            }
        }
        
        courseArea.setText(courseInfo.toString());
        coursePanel.add(new JScrollPane(courseArea), BorderLayout.CENTER);
        
        add(welcomePanel, BorderLayout.NORTH);
        add(statsPanel, BorderLayout.CENTER);
        add(coursePanel, BorderLayout.SOUTH);
    }
    
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel(title, JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(color);
        
        JLabel valueLabel = new JLabel(value, JLabel.CENTER);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(Color.BLACK);
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    private void setupLayout() {
        // Layout is already set in initializeComponents
    }
}