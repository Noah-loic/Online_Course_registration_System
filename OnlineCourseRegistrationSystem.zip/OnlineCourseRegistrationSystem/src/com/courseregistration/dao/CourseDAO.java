package com.courseregistration.dao;

import com.courseregistration.dao.PrerequisiteDAO;
import com.courseregistration.model.Course;
import com.courseregistration.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CourseDAO {
    private PrerequisiteDAO prerequisiteDAO;
    
    public CourseDAO() {
        this.prerequisiteDAO = new PrerequisiteDAO();
    }
    
    public String insert(Course course) {
        String sql = "INSERT INTO courses (course_code, title, credits, capacity, instructor_id, schedule_time, schedule_days, location, department, semester_id, description, fee, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, course.getCourseCode());
            stmt.setString(2, course.getTitle());
            stmt.setInt(3, course.getCredits());
            stmt.setInt(4, course.getCapacity());
            
            // Handle instructor assignment - set to NULL if instructor doesn't exist
            String instructorId = course.getInstructorId();
            if (instructorId != null && !instructorId.trim().isEmpty() && !instructorExists(instructorId)) {
                stmt.setNull(5, Types.VARCHAR);
            } else {
                stmt.setString(5, instructorId);
            }
            
            stmt.setString(6, course.getScheduleTime());
            stmt.setString(7, course.getScheduleDays());
            stmt.setString(8, course.getLocation());
            stmt.setString(9, course.getDepartment());
            stmt.setString(10, course.getSemesterId());
            stmt.setString(11, course.getDescription());
            stmt.setBigDecimal(12, course.getFee());
            stmt.setBoolean(13, course.isActive());
            
            return stmt.executeUpdate() > 0 ? "SUCCESS" : "Failed to insert course";
            
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) {
                return "Course code already exists";
            }
            if (e.getErrorCode() == 1452) {
                return "Instructor ID does not exist. Course created without instructor assignment.";
            }
            return "Database error: " + e.getMessage();
        }
    }
    
    private boolean instructorExists(String instructorId) {
        String sql = "SELECT COUNT(*) FROM instructors WHERE instructor_id = ?";
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, instructorId);
            ResultSet rs = stmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            return false;
        }
    }
    
    public boolean update(Course course) {
        String sql = "UPDATE courses SET title = ?, credits = ?, capacity = ?, instructor_id = ?, schedule_time = ?, schedule_days = ?, location = ?, department = ?, semester_id = ?, description = ?, fee = ?, is_active = ? WHERE course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, course.getTitle());
            stmt.setInt(2, course.getCredits());
            stmt.setInt(3, course.getCapacity());
            
            // Handle instructor assignment - set to NULL if instructor doesn't exist
            String instructorId = course.getInstructorId();
            if (instructorId != null && !instructorId.trim().isEmpty() && !instructorExists(instructorId)) {
                stmt.setNull(4, Types.VARCHAR);
            } else {
                stmt.setString(4, instructorId);
            }
            
            stmt.setString(5, course.getScheduleTime());
            stmt.setString(6, course.getScheduleDays());
            stmt.setString(7, course.getLocation());
            stmt.setString(8, course.getDepartment());
            stmt.setString(9, course.getSemesterId());
            stmt.setString(10, course.getDescription());
            stmt.setBigDecimal(11, course.getFee());
            stmt.setBoolean(12, course.isActive());
            stmt.setString(13, course.getCourseCode());
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating course: " + e.getMessage());
            return false;
        }
    }
    
    public boolean delete(String courseCode) {
        String sql = "DELETE FROM courses WHERE course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting course: " + e.getMessage());
            return false;
        }
    }
    
    public List<Course> getAll() {
        List<Course> courses = new ArrayList<>();
        String sql = "SELECT c.*, i.name as instructor_name FROM courses c LEFT JOIN instructors i ON c.instructor_id = i.instructor_id ORDER BY c.course_code";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Course course = new Course();
                course.setCourseCode(rs.getString("course_code"));
                course.setTitle(rs.getString("title"));
                course.setCredits(rs.getInt("credits"));
                course.setCapacity(rs.getInt("capacity"));
                course.setEnrolledCount(rs.getInt("enrolled_count"));
                course.setInstructorId(rs.getString("instructor_id"));
                course.setInstructorName(rs.getString("instructor_name"));
                course.setScheduleTime(rs.getString("schedule_time"));
                course.setScheduleDays(rs.getString("schedule_days"));
                course.setLocation(rs.getString("location"));
                course.setDepartment(rs.getString("department"));
                course.setSemesterId(rs.getString("semester_id"));
                course.setDescription(rs.getString("description"));
                course.setFee(rs.getBigDecimal("fee"));
                course.setActive(rs.getBoolean("is_active"));
                course.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                
                // Load prerequisites
                course.setPrerequisites(prerequisiteDAO.getPrerequisites(course.getCourseCode()));
                
                courses.add(course);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving courses: " + e.getMessage());
        }
        
        return courses;
    }
    
    public Course getById(String courseCode) {
        String sql = "SELECT c.*, i.name as instructor_name FROM courses c LEFT JOIN instructors i ON c.instructor_id = i.instructor_id WHERE c.course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Course course = new Course();
                course.setCourseCode(rs.getString("course_code"));
                course.setTitle(rs.getString("title"));
                course.setCredits(rs.getInt("credits"));
                course.setCapacity(rs.getInt("capacity"));
                course.setEnrolledCount(rs.getInt("enrolled_count"));
                course.setInstructorId(rs.getString("instructor_id"));
                course.setInstructorName(rs.getString("instructor_name"));
                course.setScheduleTime(rs.getString("schedule_time"));
                course.setScheduleDays(rs.getString("schedule_days"));
                course.setLocation(rs.getString("location"));
                course.setDepartment(rs.getString("department"));
                course.setSemesterId(rs.getString("semester_id"));
                course.setDescription(rs.getString("description"));
                course.setFee(rs.getBigDecimal("fee"));
                course.setActive(rs.getBoolean("is_active"));
                course.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                
                // Load prerequisites
                course.setPrerequisites(prerequisiteDAO.getPrerequisites(course.getCourseCode()));
                
                return course;
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving course: " + e.getMessage());
        }
        
        return null;
    }
    
    public List<Course> searchCourses(String courseCode, String title, String department) {
        List<Course> courses = new ArrayList<>();
        StringBuilder sql = new StringBuilder(
            "SELECT c.*, i.name as instructor_name FROM courses c " +
            "LEFT JOIN instructors i ON c.instructor_id = i.instructor_id WHERE 1=1");
        List<String> params = new ArrayList<>();
        
        if (courseCode != null && !courseCode.trim().isEmpty()) {
            sql.append(" AND c.course_code LIKE ?");
            params.add("%" + courseCode.trim() + "%");
        }
        
        if (title != null && !title.trim().isEmpty()) {
            sql.append(" AND c.title LIKE ?");
            params.add("%" + title.trim() + "%");
        }
        
        if (department != null && !department.trim().isEmpty()) {
            sql.append(" AND c.department LIKE ?");
            params.add("%" + department.trim() + "%");
        }
        
        sql.append(" ORDER BY c.course_code");
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {
            
            for (int i = 0; i < params.size(); i++) {
                stmt.setString(i + 1, params.get(i));
            }
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Course course = new Course();
                course.setCourseCode(rs.getString("course_code"));
                course.setTitle(rs.getString("title"));
                course.setCredits(rs.getInt("credits"));
                course.setCapacity(rs.getInt("capacity"));
                course.setEnrolledCount(rs.getInt("enrolled_count"));
                course.setInstructorId(rs.getString("instructor_id"));
                course.setInstructorName(rs.getString("instructor_name"));
                course.setScheduleTime(rs.getString("schedule_time"));
                course.setScheduleDays(rs.getString("schedule_days"));
                course.setLocation(rs.getString("location"));
                course.setDepartment(rs.getString("department"));
                course.setSemesterId(rs.getString("semester_id"));
                course.setDescription(rs.getString("description"));
                course.setFee(rs.getBigDecimal("fee"));
                course.setActive(rs.getBoolean("is_active"));
                course.setCreatedAt(rs.getTimestamp("created_at").toLocalDateTime());
                
                course.setPrerequisites(prerequisiteDAO.getPrerequisites(course.getCourseCode()));
                courses.add(course);
            }
            
        } catch (SQLException e) {
            System.err.println("Error searching courses: " + e.getMessage());
        }
        
        return courses;
    }
}