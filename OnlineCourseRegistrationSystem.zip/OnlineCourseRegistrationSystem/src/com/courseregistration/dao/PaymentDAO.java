package com.courseregistration.dao;

import com.courseregistration.model.Payment;
import com.courseregistration.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PaymentDAO {
    
    public boolean insert(Payment payment) {
        String sql = "INSERT INTO payments (student_id, amount, payment_type, payment_method, transaction_id, status, receipt_number, semester_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, payment.getStudentId());
            stmt.setBigDecimal(2, payment.getAmount());
            stmt.setString(3, payment.getPaymentType());
            stmt.setString(4, payment.getPaymentMethod());
            stmt.setString(5, payment.getTransactionId());
            stmt.setString(6, payment.getStatus());
            stmt.setString(7, payment.getReceiptNumber());
            if (payment.getSemesterId() != null) {
                stmt.setString(8, payment.getSemesterId());
            } else {
                stmt.setNull(8, Types.VARCHAR);
            }
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error inserting payment: " + e.getMessage());
            return false;
        }
    }
    
    public boolean updateStatus(int paymentId, String status) {
        String sql = "UPDATE payments SET status = ? WHERE payment_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, status);
            stmt.setInt(2, paymentId);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error updating payment status: " + e.getMessage());
            return false;
        }
    }
    
    public List<Payment> getByStudentId(String studentId) {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments WHERE student_id = ? ORDER BY payment_date DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, studentId);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Payment payment = new Payment();
                payment.setPaymentId(rs.getInt("payment_id"));
                payment.setStudentId(rs.getString("student_id"));
                payment.setAmount(rs.getBigDecimal("amount"));
                payment.setPaymentType(rs.getString("payment_type"));
                payment.setPaymentMethod(rs.getString("payment_method"));
                payment.setTransactionId(rs.getString("transaction_id"));
                payment.setPaymentDate(rs.getTimestamp("payment_date").toLocalDateTime());
                payment.setStatus(rs.getString("status"));
                payment.setReceiptNumber(rs.getString("receipt_number"));
                payment.setSemesterId(rs.getString("semester_id"));
                
                payments.add(payment);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving payments: " + e.getMessage());
        }
        
        return payments;
    }
    
    public List<Payment> getAll() {
        List<Payment> payments = new ArrayList<>();
        String sql = "SELECT * FROM payments ORDER BY payment_date DESC";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Payment payment = new Payment();
                payment.setPaymentId(rs.getInt("payment_id"));
                payment.setStudentId(rs.getString("student_id"));
                payment.setAmount(rs.getBigDecimal("amount"));
                payment.setPaymentType(rs.getString("payment_type"));
                payment.setPaymentMethod(rs.getString("payment_method"));
                payment.setTransactionId(rs.getString("transaction_id"));
                payment.setPaymentDate(rs.getTimestamp("payment_date").toLocalDateTime());
                payment.setStatus(rs.getString("status"));
                payment.setReceiptNumber(rs.getString("receipt_number"));
                payment.setSemesterId(rs.getString("semester_id"));
                
                payments.add(payment);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving all payments: " + e.getMessage());
        }
        
        return payments;
    }
}