package com.courseregistration.view;

import com.courseregistration.controller.*;
import com.courseregistration.model.*;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class AdminDashboardPanel extends JPanel {
    private StudentController studentController;
    private CourseController courseController;
    private RegistrationController registrationController;
    private InstructorController instructorController;
    
    public AdminDashboardPanel() {
        studentController = new StudentController();
        courseController = new CourseController();
        registrationController = new RegistrationController();
        instructorController = new InstructorController();
        
        initializeComponents();
        setupLayout();
    }
    
    private void initializeComponents() {
        setLayout(new GridLayout(2, 3, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Get statistics
        List<Student> students = studentController.getAllStudents();
        List<Course> courses = courseController.getAllCourses();
        List<Registration> registrations = registrationController.getAllRegistrations();
        List<Instructor> instructors = instructorController.getAllInstructors();
        
        long activeRegistrations = registrations.stream().filter(r -> "ACTIVE".equals(r.getStatus())).count();
        long completedRegistrations = registrations.stream().filter(r -> "COMPLETED".equals(r.getStatus())).count();
        
        // Create stat cards
        add(createStatCard("Total Students", String.valueOf(students.size()), Color.BLUE));
        add(createStatCard("Total Courses", String.valueOf(courses.size()), Color.GREEN));
        add(createStatCard("Total Instructors", String.valueOf(instructors.size()), Color.ORANGE));
        add(createStatCard("Active Registrations", String.valueOf(activeRegistrations), Color.RED));
        add(createStatCard("Completed Courses", String.valueOf(completedRegistrations), Color.MAGENTA));
        add(createStatCard("Total Registrations", String.valueOf(registrations.size()), Color.CYAN));
    }
    
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(color, 2),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        card.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel(title, JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(color);
        
        JLabel valueLabel = new JLabel(value, JLabel.CENTER);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(Color.BLACK);
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    private void setupLayout() {
        // Layout is already set in initializeComponents
    }
}