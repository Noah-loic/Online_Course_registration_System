package com.courseregistration.model;

import java.time.LocalDateTime;

public class Waitlist {
    private int waitlistId;
    private String studentId;
    private String courseCode;
    private int position;
    private LocalDateTime waitlistDate;
    private boolean notified;
    
    // For display purposes
    private String studentName;
    private String courseTitle;

    public Waitlist() {}

    public Waitlist(String studentId, String courseCode, int position) {
        this.studentId = studentId;
        this.courseCode = courseCode;
        this.position = position;
        this.notified = false;
    }

    // Getters and Setters
    public int getWaitlistId() { return waitlistId; }
    public void setWaitlistId(int waitlistId) { this.waitlistId = waitlistId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }

    public int getPosition() { return position; }
    public void setPosition(int position) { this.position = position; }

    public LocalDateTime getWaitlistDate() { return waitlistDate; }
    public void setWaitlistDate(LocalDateTime waitlistDate) { this.waitlistDate = waitlistDate; }

    public boolean isNotified() { return notified; }
    public void setNotified(boolean notified) { this.notified = notified; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getCourseTitle() { return courseTitle; }
    public void setCourseTitle(String courseTitle) { this.courseTitle = courseTitle; }
}