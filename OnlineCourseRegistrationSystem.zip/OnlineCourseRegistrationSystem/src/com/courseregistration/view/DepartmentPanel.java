package com.courseregistration.view;

import com.courseregistration.dao.DepartmentDAO;
import com.courseregistration.model.Department;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class DepartmentPanel extends JPanel {
    private DepartmentDAO departmentDAO;
    private JTable departmentTable;
    private DefaultTableModel tableModel;
    private JTextField txtDeptId, txtDeptName, txtOfficeLocation;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    
    public DepartmentPanel() {
        departmentDAO = new DepartmentDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadDepartments();
    }
    
    private void initializeComponents() {
        // Table
        String[] columns = {"Department ID", "Department Name", "Office Location"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        departmentTable = new JTable(tableModel);
        departmentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Form fields
        txtDeptId = new JTextField(10);
        txtDeptName = new JTextField(20);
        txtOfficeLocation = new JTextField(20);
        
        // Buttons
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Department Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Department ID:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtDeptId, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Department Name:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtDeptName, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Office Location:"), gbc);
        gbc.gridx = 1;
        formPanel.add(txtOfficeLocation, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnRefresh);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        formPanel.add(buttonPanel, gbc);
        
        // Table panel
        JScrollPane scrollPane = new JScrollPane(departmentTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Departments"));
        
        add(formPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnAdd.addActionListener(e -> addDepartment());
        btnUpdate.addActionListener(e -> updateDepartment());
        btnDelete.addActionListener(e -> deleteDepartment());
        btnRefresh.addActionListener(e -> loadDepartments());
        
        departmentTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedDepartment();
            }
        });
    }
    
    private void loadDepartments() {
        tableModel.setRowCount(0);
        List<Department> departments = departmentDAO.getAll();
        
        for (Department dept : departments) {
            Object[] row = {
                dept.getDeptId(),
                dept.getDeptName(),
                dept.getOfficeLocation()
            };
            tableModel.addRow(row);
        }
    }
    
    private void loadSelectedDepartment() {
        int selectedRow = departmentTable.getSelectedRow();
        if (selectedRow >= 0) {
            txtDeptId.setText((String) tableModel.getValueAt(selectedRow, 0));
            txtDeptName.setText((String) tableModel.getValueAt(selectedRow, 1));
            txtOfficeLocation.setText((String) tableModel.getValueAt(selectedRow, 2));
        }
    }
    
    private void addDepartment() {
        if (!validateInput()) return;
        
        Department dept = new Department(
            txtDeptId.getText().trim(),
            txtDeptName.getText().trim(),
            txtOfficeLocation.getText().trim()
        );
        
        String result = departmentDAO.insert(dept);
        if ("SUCCESS".equals(result)) {
            JOptionPane.showMessageDialog(this, "Department added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadDepartments();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add department:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateDepartment() {
        if (!validateInput()) return;
        
        Department dept = new Department(
            txtDeptId.getText().trim(),
            txtDeptName.getText().trim(),
            txtOfficeLocation.getText().trim()
        );
        
        String result = departmentDAO.update(dept);
        if ("SUCCESS".equals(result)) {
            JOptionPane.showMessageDialog(this, "Department updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadDepartments();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update department:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteDepartment() {
        String deptId = txtDeptId.getText().trim();
        if (deptId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select a department to delete!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this department?", 
            "Confirm Delete", 
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            String result = departmentDAO.delete(deptId);
            if ("SUCCESS".equals(result)) {
                JOptionPane.showMessageDialog(this, "Department deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadDepartments();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete department:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private boolean validateInput() {
        if (txtDeptId.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Department ID is required!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        if (txtDeptName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Department Name is required!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
    
    private void clearForm() {
        txtDeptId.setText("");
        txtDeptName.setText("");
        txtOfficeLocation.setText("");
        departmentTable.clearSelection();
    }
}