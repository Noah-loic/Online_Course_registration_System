package com.courseregistration.view;

import com.courseregistration.dao.PaymentDAO;
import com.courseregistration.model.Payment;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

public class PaymentPanel extends JPanel {
    private PaymentDAO paymentDAO;
    private JTextField txtStudentId, txtAmount, txtTransactionId, txtReceiptNumber;
    private JComboBox<String> cmbPaymentType, cmbPaymentMethod, cmbStatus;
    private JTable paymentTable;
    private DefaultTableModel tableModel;
    private JButton btnProcessPayment, btnUpdateStatus, btnRefresh, btnGenerateReceipt;
    
    public PaymentPanel() {
        paymentDAO = new PaymentDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        refreshTable();
    }
    
    private void initializeComponents() {
        // Input fields
        txtStudentId = new JTextField(15);
        txtAmount = new JTextField(10);
        txtTransactionId = new JTextField(20);
        txtReceiptNumber = new JTextField(15);
        
        // Combo boxes
        cmbPaymentType = new JComboBox<>(new String[]{"TUITION", "FEE", "FINE"});
        cmbPaymentMethod = new JComboBox<>(new String[]{"CREDIT_CARD", "DEBIT_CARD", "BANK_TRANSFER", "CASH"});
        cmbStatus = new JComboBox<>(new String[]{"PENDING", "COMPLETED", "FAILED", "REFUNDED"});
        
        // Buttons
        btnProcessPayment = new JButton("Process Payment");
        btnUpdateStatus = new JButton("Update Status");
        btnRefresh = new JButton("Refresh");
        btnGenerateReceipt = new JButton("Generate Receipt");
        
        // Table
        String[] columnNames = {"Payment ID", "Student ID", "Amount", "Type", "Method", "Status", "Date", "Receipt #"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        paymentTable = new JTable(tableModel);
        paymentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        paymentTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedPayment();
            }
        });
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Payment Information"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Student ID
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(new JLabel("Student ID:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtStudentId, gbc);
        
        // Amount
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Amount:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtAmount, gbc);
        
        // Payment Type
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Type:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(cmbPaymentType, gbc);
        
        // Payment Method
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Method:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(cmbPaymentMethod, gbc);
        
        // Transaction ID
        gbc.gridx = 0; gbc.gridy = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Transaction ID:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtTransactionId, gbc);
        
        // Status
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(cmbStatus, gbc);
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnProcessPayment);
        buttonPanel.add(btnUpdateStatus);
        buttonPanel.add(btnGenerateReceipt);
        buttonPanel.add(btnRefresh);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Payment History"));
        tablePanel.add(new JScrollPane(paymentTable), BorderLayout.CENTER);
        
        // Main layout
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(formPanel, BorderLayout.CENTER);
        topPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(topPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnProcessPayment.addActionListener(e -> processPayment());
        btnUpdateStatus.addActionListener(e -> updatePaymentStatus());
        btnGenerateReceipt.addActionListener(e -> generateReceipt());
        btnRefresh.addActionListener(e -> refreshTable());
    }
    
    private void processPayment() {
        try {
            String studentId = txtStudentId.getText().trim();
            BigDecimal amount = new BigDecimal(txtAmount.getText().trim());
            String paymentType = (String) cmbPaymentType.getSelectedItem();
            String paymentMethod = (String) cmbPaymentMethod.getSelectedItem();
            String transactionId = txtTransactionId.getText().trim();
            
            if (studentId.isEmpty() || amount.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(this, "Please enter valid student ID and amount.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            Payment payment = new Payment(studentId, amount, paymentType, paymentMethod, "2024SP");
            payment.setTransactionId(transactionId.isEmpty() ? generateTransactionId() : transactionId);
            payment.setReceiptNumber(generateReceiptNumber());
            payment.setStatus("COMPLETED");
            
            if (paymentDAO.insert(payment)) {
                JOptionPane.showMessageDialog(this, "Payment processed successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
                refreshTable();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to process payment.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter a valid amount.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updatePaymentStatus() {
        int selectedRow = paymentTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a payment to update.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int paymentId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String status = (String) cmbStatus.getSelectedItem();
        
        if (paymentDAO.updateStatus(paymentId, status)) {
            JOptionPane.showMessageDialog(this, "Payment status updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            refreshTable();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update payment status.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void generateReceipt() {
        int selectedRow = paymentTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a payment to generate receipt.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        // Simple receipt generation
        StringBuilder receipt = new StringBuilder();
        receipt.append("PAYMENT RECEIPT\n");
        receipt.append("================\n");
        receipt.append("Payment ID: ").append(tableModel.getValueAt(selectedRow, 0)).append("\n");
        receipt.append("Student ID: ").append(tableModel.getValueAt(selectedRow, 1)).append("\n");
        receipt.append("Amount: $").append(tableModel.getValueAt(selectedRow, 2)).append("\n");
        receipt.append("Type: ").append(tableModel.getValueAt(selectedRow, 3)).append("\n");
        receipt.append("Method: ").append(tableModel.getValueAt(selectedRow, 4)).append("\n");
        receipt.append("Status: ").append(tableModel.getValueAt(selectedRow, 5)).append("\n");
        receipt.append("Date: ").append(tableModel.getValueAt(selectedRow, 6)).append("\n");
        receipt.append("Receipt #: ").append(tableModel.getValueAt(selectedRow, 7)).append("\n");
        
        JTextArea textArea = new JTextArea(receipt.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        
        JOptionPane.showMessageDialog(this, scrollPane, "Payment Receipt", JOptionPane.INFORMATION_MESSAGE);
    }
    
    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Payment> payments = paymentDAO.getAll();
        
        for (Payment payment : payments) {
            Object[] row = {
                payment.getPaymentId(),
                payment.getStudentId(),
                payment.getAmount(),
                payment.getPaymentType(),
                payment.getPaymentMethod(),
                payment.getStatus(),
                payment.getPaymentDate(),
                payment.getReceiptNumber()
            };
            tableModel.addRow(row);
        }
    }
    
    private void loadSelectedPayment() {
        int selectedRow = paymentTable.getSelectedRow();
        if (selectedRow >= 0) {
            txtStudentId.setText((String) tableModel.getValueAt(selectedRow, 1));
            txtAmount.setText(tableModel.getValueAt(selectedRow, 2).toString());
            cmbPaymentType.setSelectedItem(tableModel.getValueAt(selectedRow, 3));
            cmbPaymentMethod.setSelectedItem(tableModel.getValueAt(selectedRow, 4));
            cmbStatus.setSelectedItem(tableModel.getValueAt(selectedRow, 5));
        }
    }
    
    private void clearFields() {
        txtStudentId.setText("");
        txtAmount.setText("");
        txtTransactionId.setText("");
        txtReceiptNumber.setText("");
        cmbPaymentType.setSelectedIndex(0);
        cmbPaymentMethod.setSelectedIndex(0);
        cmbStatus.setSelectedIndex(0);
    }
    
    private String generateTransactionId() {
        return "TXN" + System.currentTimeMillis();
    }
    
    private String generateReceiptNumber() {
        return "RCP" + System.currentTimeMillis();
    }
}