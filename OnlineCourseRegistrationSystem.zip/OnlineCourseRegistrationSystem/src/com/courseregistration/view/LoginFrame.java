package com.courseregistration.view;

import com.courseregistration.controller.AuthController;
import com.courseregistration.model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginFrame extends JFrame {
    private AuthController authController;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin, btnRegister, btnExit;
    private JLabel lblTitle;
    
    public LoginFrame() {
        authController = new AuthController();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        setupFrame();
    }
    
    private void initializeComponents() {
        lblTitle = new JLabel("Online Course Registration System", JLabel.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        
        txtUsername = new JTextField(20);
        txtPassword = new JPasswordField(20);
        
        btnLogin = new JButton("Login");
        btnRegister = new JButton("Register");
        btnExit = new JButton("Exit");
        
        // Set default credentials for demo
        txtUsername.setText("admin");
        txtPassword.setText("admin123");
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Title panel
        JPanel titlePanel = new JPanel();
        titlePanel.add(lblTitle);
        titlePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Login form panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Login"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        // Username
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtUsername, gbc);
        
        // Password
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtPassword, gbc);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnLogin);
        buttonPanel.add(btnRegister);
        buttonPanel.add(btnExit);
        
        /*
        // Demo credentials panel
        JPanel demoPanel = new JPanel();
        demoPanel.setBorder(BorderFactory.createTitledBorder("Demo Credentials"));
        demoPanel.setLayout(new BoxLayout(demoPanel, BoxLayout.Y_AXIS));
        demoPanel.add(new JLabel("Admin: admin / admin123"));
        demoPanel.add(new JLabel("Student: john.doe / pass123"));
        demoPanel.add(new JLabel("Instructor: dr.anderson / pass123"));
        */ 
        
        add(titlePanel, BorderLayout.NORTH);
        add(formPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
       // add(demoPanel, BorderLayout.EAST);
    }
    
    private void setupEventHandlers() {
        btnLogin.addActionListener(e -> login());
        btnRegister.addActionListener(e -> showRegisterDialog());
        btnExit.addActionListener(e -> System.exit(0));
        
        // Enter key login
        txtPassword.addActionListener(e -> login());
    }
    
    private void setupFrame() {
        setTitle("Course Registration System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setResizable(false);
    }
    
    private void login() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());
        
        User user = authController.login(username, password);
        
        if (user != null) {
            // Open main application based on role
            SwingUtilities.invokeLater(() -> {
                MainFrame mainFrame = new MainFrame(authController);
                mainFrame.setVisible(true);
                this.dispose();
            });
        }
    }
    
    private void showRegisterDialog() {
        JDialog registerDialog = new JDialog(this, "Register Account", true);
        registerDialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        JTextField txtStudentInstructorId = new JTextField(15);
        JTextField txtUsername = new JTextField(15);
        JPasswordField txtPassword = new JPasswordField(15);
        JPasswordField txtConfirmPassword = new JPasswordField(15);
        
        gbc.gridx = 0; gbc.gridy = 0;
        registerDialog.add(new JLabel("Student/Instructor ID:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(txtStudentInstructorId, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        registerDialog.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(txtUsername, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        registerDialog.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(txtPassword, gbc);
        
        gbc.gridx = 0; gbc.gridy = 3;
        registerDialog.add(new JLabel("Confirm Password:"), gbc);
        gbc.gridx = 1;
        registerDialog.add(txtConfirmPassword, gbc);
        
        JPanel buttonPanel = new JPanel();
        JButton btnRegisterUser = new JButton("Register");
        JButton btnCancel = new JButton("Cancel");
        
        btnRegisterUser.addActionListener(e -> {
            String studentInstructorId = txtStudentInstructorId.getText().trim();
            String username = txtUsername.getText().trim();
            String password = new String(txtPassword.getPassword());
            String confirmPassword = new String(txtConfirmPassword.getPassword());
            
            if (!password.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(registerDialog, "Passwords do not match!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (authController.registerExistingUser(studentInstructorId, username, password)) {
                JOptionPane.showMessageDialog(registerDialog, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                registerDialog.dispose();
            }
        });
        
        btnCancel.addActionListener(e -> registerDialog.dispose());
        
        buttonPanel.add(btnRegisterUser);
        buttonPanel.add(btnCancel);
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        registerDialog.add(buttonPanel, gbc);
        
        // Add instruction label
        JLabel instructionLabel = new JLabel("<html><center>Enter your Student ID or Instructor ID<br>as provided by the admin</center></html>");
        instructionLabel.setFont(instructionLabel.getFont().deriveFont(Font.ITALIC));
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        registerDialog.add(instructionLabel, gbc);
        
        registerDialog.pack();
        registerDialog.setLocationRelativeTo(this);
        registerDialog.setVisible(true);
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}