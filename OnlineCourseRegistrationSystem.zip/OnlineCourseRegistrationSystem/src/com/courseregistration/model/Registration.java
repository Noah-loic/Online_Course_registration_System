package com.courseregistration.model;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Registration {
    private int registrationId;
    private String studentId;
    private String courseCode;
    private LocalDate registrationDate;
    private String status;
    private String grade;
    private LocalDateTime createdAt;
    
    // For display purposes
    private String studentName;
    private String courseTitle;

    public Registration() {}

    public Registration(String studentId, String courseCode, LocalDate registrationDate, String status) {
        this.studentId = studentId;
        this.courseCode = courseCode;
        this.registrationDate = registrationDate;
        this.status = status;
    }

    // Getters and Setters
    public int getRegistrationId() { return registrationId; }
    public void setRegistrationId(int registrationId) { this.registrationId = registrationId; }

    public String getStudentId() { return studentId; }
    public void setStudentId(String studentId) { this.studentId = studentId; }

    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }

    public LocalDate getRegistrationDate() { return registrationDate; }
    public void setRegistrationDate(LocalDate registrationDate) { this.registrationDate = registrationDate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getCourseTitle() { return courseTitle; }
    public void setCourseTitle(String courseTitle) { this.courseTitle = courseTitle; }

    @Override
    public String toString() {
        return "Registration{" +
                "registrationId=" + registrationId +
                ", studentId='" + studentId + '\'' +
                ", courseCode='" + courseCode + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}