package com.courseregistration.view;

import com.courseregistration.controller.RegistrationController;
import com.courseregistration.controller.StudentController;
import com.courseregistration.controller.CourseController;
import com.courseregistration.model.Registration;
import com.courseregistration.model.Student;
import com.courseregistration.model.Course;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class RegistrationPanel extends JPanel {
    private RegistrationController registrationController;
    private StudentController studentController;
    private CourseController courseController;
    
    private JComboBox<String> cmbStudentId, cmbCourseCode;
    private JComboBox<String> cmbStatus;
    private JTextField txtGrade;
    private JTable registrationTable;
    private DefaultTableModel tableModel;
    private JButton btnRegister, btnUpdate, btnDrop, btnRefresh, btnClear;
    
    // Search components
    private JTextField txtSearchCourse, txtSearchStudent, txtSearchGrade;
    private JButton btnSearch, btnClearSearch;
    
    public RegistrationPanel() {
        registrationController = new RegistrationController();
        studentController = new StudentController();
        courseController = new CourseController();
        
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadComboBoxData();
        refreshTable();
    }
    
    private void initializeComponents() {
        // Combo boxes
        cmbStudentId = new JComboBox<>();
        cmbCourseCode = new JComboBox<>();
        cmbStatus = new JComboBox<>(new String[]{"ACTIVE", "DROPPED", "COMPLETED"});
        txtGrade = new JTextField(5);
        
        // Buttons
        btnRegister = new JButton("Register Student");
        btnUpdate = new JButton("Update Registration");
        btnDrop = new JButton("Drop Registration");
        btnRefresh = new JButton("Refresh");
        btnClear = new JButton("Clear");
        
        // Search components
        txtSearchCourse = new JTextField(10);
        txtSearchStudent = new JTextField(10);
        txtSearchGrade = new JTextField(5);
        btnSearch = new JButton("Search");
        btnClearSearch = new JButton("Clear Search");
        
        // Table
        String[] columnNames = {"Registration ID", "Student ID", "Student Name", "Course Code", "Course Title", "Date", "Status", "Grade"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        registrationTable = new JTable(tableModel);
        registrationTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        registrationTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedRegistration();
            }
        });
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Form Panel
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Registration Information"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Student ID
        gbc.gridx = 0; gbc.gridy = 0; gbc.anchor = GridBagConstraints.WEST;
        formPanel.add(new JLabel("Student:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(cmbStudentId, gbc);
        
        // Course Code
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Course:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(cmbCourseCode, gbc);
        
        // Status
        gbc.gridx = 0; gbc.gridy = 1; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Status:"), gbc);
        gbc.gridx = 1; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(cmbStatus, gbc);
        
        // Grade
        gbc.gridx = 2; gbc.fill = GridBagConstraints.NONE;
        formPanel.add(new JLabel("Grade:"), gbc);
        gbc.gridx = 3; gbc.fill = GridBagConstraints.HORIZONTAL;
        formPanel.add(txtGrade, gbc);
        
        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnRegister);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDrop);
        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnClear);
        
        // Search Panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search Registrations"));
        searchPanel.add(new JLabel("Course:"));
        searchPanel.add(txtSearchCourse);
        searchPanel.add(new JLabel("Student:"));
        searchPanel.add(txtSearchStudent);
        searchPanel.add(new JLabel("Grade:"));
        searchPanel.add(txtSearchGrade);
        searchPanel.add(btnSearch);
        searchPanel.add(btnClearSearch);
        
        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBorder(BorderFactory.createTitledBorder("Registrations List"));
        tablePanel.add(searchPanel, BorderLayout.NORTH);
        tablePanel.add(new JScrollPane(registrationTable), BorderLayout.CENTER);
        
        // Control Panel
        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.add(formPanel, BorderLayout.CENTER);
        controlPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        add(controlPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnRegister.addActionListener(e -> registerStudent());
        btnUpdate.addActionListener(e -> updateRegistration());
        btnDrop.addActionListener(e -> dropRegistration());
        btnRefresh.addActionListener(e -> {
            loadComboBoxData();
            refreshTable();
        });
        btnClear.addActionListener(e -> clearFields());
        btnSearch.addActionListener(e -> searchRegistrations());
        btnClearSearch.addActionListener(e -> clearSearch());
    }
    
    private void loadComboBoxData() {
        // Load students
        cmbStudentId.removeAllItems();
        List<Student> students = studentController.getAllStudents();
        for (Student student : students) {
            cmbStudentId.addItem(student.getStudentId() + " - " + student.getName());
        }
        
        // Load courses
        cmbCourseCode.removeAllItems();
        List<Course> courses = courseController.getAllCourses();
        for (Course course : courses) {
            cmbCourseCode.addItem(course.getCourseCode() + " - " + course.getTitle());
        }
    }
    
    private void registerStudent() {
        String studentSelection = (String) cmbStudentId.getSelectedItem();
        String courseSelection = (String) cmbCourseCode.getSelectedItem();
        
        if (studentSelection == null || courseSelection == null) {
            JOptionPane.showMessageDialog(this, "Please select both student and course.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String studentId = studentSelection.split(" - ")[0];
        String courseCode = courseSelection.split(" - ")[0];
        
        if (registrationController.registerStudent(studentId, courseCode)) {
            clearFields();
            refreshTable();
        }
    }
    
    private void updateRegistration() {
        int selectedRow = registrationTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a registration to update.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int registrationId = (Integer) tableModel.getValueAt(selectedRow, 0);
        String status = (String) cmbStatus.getSelectedItem();
        String grade = txtGrade.getText().trim();
        
        if (registrationController.updateRegistration(registrationId, status, grade)) {
            clearFields();
            refreshTable();
        }
    }
    
    private void dropRegistration() {
        int selectedRow = registrationTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a registration to drop.", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int registrationId = (Integer) tableModel.getValueAt(selectedRow, 0);
        
        if (registrationController.dropRegistration(registrationId)) {
            clearFields();
            refreshTable();
        }
    }
    
    private void refreshTable() {
        tableModel.setRowCount(0);
        List<Registration> registrations = registrationController.getAllRegistrations();
        
        for (Registration registration : registrations) {
            Object[] row = {
                registration.getRegistrationId(),
                registration.getStudentId(),
                registration.getStudentName(),
                registration.getCourseCode(),
                registration.getCourseTitle(),
                registration.getRegistrationDate(),
                registration.getStatus(),
                registration.getGrade()
            };
            tableModel.addRow(row);
        }
    }
    
    private void loadSelectedRegistration() {
        int selectedRow = registrationTable.getSelectedRow();
        if (selectedRow >= 0) {
            String studentId = (String) tableModel.getValueAt(selectedRow, 1);
            String courseCode = (String) tableModel.getValueAt(selectedRow, 3);
            String status = (String) tableModel.getValueAt(selectedRow, 6);
            String grade = (String) tableModel.getValueAt(selectedRow, 7);
            
            // Set combo box selections
            for (int i = 0; i < cmbStudentId.getItemCount(); i++) {
                if (cmbStudentId.getItemAt(i).startsWith(studentId)) {
                    cmbStudentId.setSelectedIndex(i);
                    break;
                }
            }
            
            for (int i = 0; i < cmbCourseCode.getItemCount(); i++) {
                if (cmbCourseCode.getItemAt(i).startsWith(courseCode)) {
                    cmbCourseCode.setSelectedIndex(i);
                    break;
                }
            }
            
            cmbStatus.setSelectedItem(status);
            txtGrade.setText(grade != null ? grade : "");
        }
    }
    
    private void clearFields() {
        cmbStudentId.setSelectedIndex(-1);
        cmbCourseCode.setSelectedIndex(-1);
        cmbStatus.setSelectedIndex(0);
        txtGrade.setText("");
        registrationTable.clearSelection();
    }
    
    private void searchRegistrations() {
        String courseCode = txtSearchCourse.getText().trim();
        String student = txtSearchStudent.getText().trim();
        String grade = txtSearchGrade.getText().trim();
        
        tableModel.setRowCount(0);
        List<Registration> registrations = registrationController.searchRegistrations(courseCode, student, grade);
        
        for (Registration registration : registrations) {
            Object[] row = {
                registration.getRegistrationId(),
                registration.getStudentId(),
                registration.getStudentName(),
                registration.getCourseCode(),
                registration.getCourseTitle(),
                registration.getRegistrationDate(),
                registration.getStatus(),
                registration.getGrade()
            };
            tableModel.addRow(row);
        }
    }
    
    private void clearSearch() {
        txtSearchCourse.setText("");
        txtSearchStudent.setText("");
        txtSearchGrade.setText("");
        refreshTable();
    }
}