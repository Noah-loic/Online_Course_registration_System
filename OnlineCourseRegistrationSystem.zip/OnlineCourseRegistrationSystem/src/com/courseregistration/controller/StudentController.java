package com.courseregistration.controller;

import com.courseregistration.dao.StudentDAO;
import com.courseregistration.model.Student;

import javax.swing.*;
import java.util.List;

public class StudentController {
    private StudentDAO studentDAO;
    
    public StudentController() {
        this.studentDAO = new StudentDAO();
    }
    
    public boolean addStudent(String studentId, String name, String email, String phone, String address) {
        if (validateStudentData(studentId, name, email)) {
            Student student = new Student(studentId, name, email, phone, address);
            String result = studentDAO.insert(student);
            
            if ("SUCCESS".equals(result)) {
                JOptionPane.showMessageDialog(null, "Student added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add student:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        return false;
    }
    
    public boolean updateStudent(String studentId, String name, String email, String phone, String address) {
        if (validateStudentData(studentId, name, email)) {
            Student student = new Student(studentId, name, email, phone, address);
            boolean success = studentDAO.update(student);
            
            if (success) {
                JOptionPane.showMessageDialog(null, "Student updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to update student. Student might not exist.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            return success;
        }
        return false;
    }
    
    public boolean deleteStudent(String studentId) {
        if (studentId == null || studentId.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a student to delete.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to delete student: " + studentId + "?", 
            "Confirm Delete", 
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = studentDAO.delete(studentId);
            
            if (success) {
                JOptionPane.showMessageDialog(null, "Student deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to delete student.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            return success;
        }
        
        return false;
    }
    
    public List<Student> getAllStudents() {
        return studentDAO.getAll();
    }
    
    public Student getStudentById(String studentId) {
        return studentDAO.getById(studentId);
    }
    
    public List<Student> searchStudents(String studentId, String name, String email) {
        return studentDAO.searchStudents(studentId, name, email);
    }
    
    private boolean validateStudentData(String studentId, String name, String email) {
        if (studentId == null || studentId.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Student ID is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (name == null || name.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Student name is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (email == null || email.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Email is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (!email.contains("@") || !email.contains(".")) {
            JOptionPane.showMessageDialog(null, "Please enter a valid email address.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
}