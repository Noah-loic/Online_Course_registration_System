-- Online Course Registration System Database Schema - Complete Implementation

CREATE DATABASE IF NOT EXISTS course_registration_db;
USE course_registration_db;

-- Users table for authentication
CREATE TABLE users (
    user_id VARCHAR(20) PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    role ENUM('STUDENT', 'INSTRUCTOR', 'ADMIN') NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP NULL,
    password_reset_token VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Students table
CREATE TABLE students (
    student_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    address TEXT,
    max_credits INT DEFAULT 18,
    min_credits INT DEFAULT 12,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Instructors table
CREATE TABLE instructors (
    instructor_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(15),
    department VARCHAR(50),
    specialization VARCHAR(200),
    office_hours VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Departments table
CREATE TABLE departments (
    dept_id VARCHAR(10) PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL,
    office_location VARCHAR(100)
);

-- Semesters table
CREATE TABLE semesters (
    semester_id VARCHAR(10) PRIMARY KEY,
    semester_name VARCHAR(50) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    registration_start DATE NOT NULL,
    registration_end DATE NOT NULL,
    is_current BOOLEAN DEFAULT FALSE
);

-- Prerequisites table
CREATE TABLE prerequisites (
    prereq_id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(10),
    prerequisite_code VARCHAR(10),
    INDEX idx_course_code (course_code),
    INDEX idx_prerequisite_code (prerequisite_code)
);

-- Courses table (enhanced)
CREATE TABLE courses (
    course_code VARCHAR(10) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    credits INT NOT NULL,
    capacity INT NOT NULL,
    enrolled_count INT DEFAULT 0,
    instructor_id VARCHAR(20),
    schedule_time VARCHAR(50),
    schedule_days VARCHAR(20),
    location VARCHAR(100),
    department VARCHAR(50),
    semester_id VARCHAR(10),
    description TEXT,
    fee DECIMAL(10,2) DEFAULT 0.00,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (instructor_id) REFERENCES instructors(instructor_id),
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id)
);

-- Registrations table (enhanced)
CREATE TABLE registrations (
    registration_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20),
    course_code VARCHAR(10),
    registration_date DATE NOT NULL,
    status ENUM('PENDING', 'APPROVED', 'ACTIVE', 'DROPPED', 'COMPLETED', 'WAITLISTED') DEFAULT 'PENDING',
    grade VARCHAR(2) DEFAULT NULL,
    approval_required BOOLEAN DEFAULT FALSE,
    approved_by VARCHAR(20) NULL,
    approval_date DATE NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES users(user_id),
    UNIQUE KEY unique_registration (student_id, course_code)
);

-- Waitlist table
CREATE TABLE waitlist (
    waitlist_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20),
    course_code VARCHAR(10),
    position INT,
    waitlist_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notified BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    UNIQUE KEY unique_waitlist (student_id, course_code)
);

-- Payments table
CREATE TABLE payments (
    payment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20),
    amount DECIMAL(10,2) NOT NULL,
    payment_type ENUM('TUITION', 'FEE', 'FINE') DEFAULT 'TUITION',
    payment_method ENUM('CREDIT_CARD', 'DEBIT_CARD', 'BANK_TRANSFER', 'CASH') NOT NULL,
    transaction_id VARCHAR(100),
    payment_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status ENUM('PENDING', 'COMPLETED', 'FAILED', 'REFUNDED') DEFAULT 'PENDING',
    receipt_number VARCHAR(50),
    semester_id VARCHAR(10),
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id)
);

-- Shopping cart table
CREATE TABLE shopping_cart (
    cart_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20),
    course_code VARCHAR(10),
    added_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_item (student_id, course_code)
);

-- Timetable table
CREATE TABLE timetables (
    timetable_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(20),
    semester_id VARCHAR(10),
    generated_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (semester_id) REFERENCES semesters(semester_id)
);

-- Notifications table
CREATE TABLE notifications (
    notification_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(20),
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('INFO', 'WARNING', 'SUCCESS', 'ERROR') DEFAULT 'INFO',
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
);

-- Insert sample data

-- Insert departments
INSERT INTO departments (dept_id, dept_name, office_location) VALUES
('CS', 'Computer Science', 'Building A, Floor 3'),
('MATH', 'Mathematics', 'Building B, Floor 2'),
('ENG', 'English', 'Building C, Floor 1'),
('PHYS', 'Physics', 'Building D, Floor 2');

-- Insert semesters
INSERT INTO semesters (semester_id, semester_name, start_date, end_date, registration_start, registration_end, is_current) VALUES
('2024SP', 'Spring 2024', '2024-01-15', '2024-05-15', '2024-01-01', '2024-01-31', TRUE),
('2024FA', 'Fall 2024', '2024-08-15', '2024-12-15', '2024-08-01', '2024-08-31', FALSE);

-- Insert users (password is 'password123' hashed)
INSERT INTO users (user_id, username, password, email, role) VALUES
('ADMIN001', 'admin', 'admin123', 'admin@university.edu', 'ADMIN'),
('S001', 'john.doe', 'pass123', 'john.doe@email.com', 'STUDENT'),
('S002', 'jane.smith', 'pass123', 'jane.smith@email.com', 'STUDENT'),
('S003', 'mike.johnson', 'pass123', 'mike.johnson@email.com', 'STUDENT'),
('I001', 'dr.anderson', 'pass123', 'anderson@university.edu', 'INSTRUCTOR'),
('I002', 'dr.brown', 'pass123', 'brown@university.edu', 'INSTRUCTOR'),
('I003', 'dr.wilson', 'pass123', 'wilson@university.edu', 'INSTRUCTOR'),
('I004', 'prof.davis', 'pass123', 'davis@university.edu', 'INSTRUCTOR');

-- Insert instructors
INSERT INTO instructors (instructor_id, name, email, phone, department, specialization, office_hours) VALUES
('I001', 'Dr. Anderson', 'anderson@university.edu', '555-0101', 'CS', 'Programming Languages', 'MWF 2:00-4:00'),
('I002', 'Dr. Brown', 'brown@university.edu', '555-0102', 'CS', 'Data Structures & Algorithms', 'TTh 1:00-3:00'),
('I003', 'Dr. Wilson', 'wilson@university.edu', '555-0103', 'MATH', 'Calculus & Analysis', 'MWF 11:00-1:00'),
('I004', 'Prof. Davis', 'davis@university.edu', '555-0104', 'ENG', 'Composition & Literature', 'TTh 10:00-12:00');

-- Insert students
INSERT INTO students (student_id, name, email, phone, address) VALUES
('S001', 'John Doe', 'john.doe@email.com', '123-456-7890', '123 Main St'),
('S002', 'Jane Smith', 'jane.smith@email.com', '098-765-4321', '456 Oak Ave'),
('S003', 'Mike Johnson', 'mike.johnson@email.com', '555-123-4567', '789 Pine Rd');

-- Insert courses
INSERT INTO courses (course_code, title, credits, capacity, instructor_id, schedule_time, schedule_days, location, department, semester_id, description, fee) VALUES
('CS101', 'Introduction to Programming', 3, 30, 'I001', '9:00-10:00', 'MWF', 'Room 101', 'CS', '2024SP', 'Basic programming concepts', 1200.00),
('CS201', 'Data Structures', 4, 25, 'I002', '11:00-12:30', 'TTh', 'Room 102', 'CS', '2024SP', 'Advanced data structures and algorithms', 1600.00),
('MATH101', 'Calculus I', 4, 40, 'I003', '10:00-11:00', 'MWF', 'Room 201', 'MATH', '2024SP', 'Differential calculus', 1600.00),
('ENG101', 'English Composition', 3, 35, 'I004', '2:00-3:30', 'TTh', 'Room 301', 'ENG', '2024SP', 'Academic writing skills', 1200.00),
('CS102', 'Programming II', 3, 25, 'I001', '1:00-2:00', 'MWF', 'Room 103', 'CS', '2024SP', 'Advanced programming concepts', 1200.00);

-- Insert prerequisites
INSERT INTO prerequisites (course_code, prerequisite_code) VALUES
('CS201', 'CS101'),
('CS102', 'CS101');

-- Insert registrations
INSERT INTO registrations (student_id, course_code, registration_date, status) VALUES
('S001', 'CS101', '2024-01-15', 'ACTIVE'),
('S001', 'MATH101', '2024-01-15', 'ACTIVE'),
('S002', 'CS101', '2024-01-16', 'ACTIVE'),
('S002', 'ENG101', '2024-01-16', 'ACTIVE'),
('S003', 'CS201', '2024-01-17', 'PENDING');

-- Add foreign key constraints for prerequisites table
ALTER TABLE prerequisites ADD CONSTRAINT fk_prereq_course FOREIGN KEY (course_code) REFERENCES courses(course_code) ON DELETE CASCADE;
ALTER TABLE prerequisites ADD CONSTRAINT fk_prereq_prerequisite FOREIGN KEY (prerequisite_code) REFERENCES courses(course_code) ON DELETE CASCADE;

-- Update enrolled counts
UPDATE courses SET enrolled_count = (SELECT COUNT(*) FROM registrations WHERE registrations.course_code = courses.course_code AND status IN ('ACTIVE', 'COMPLETED'));