package com.courseregistration.model;

import java.time.LocalDateTime;

public class Instructor {
    private String instructorId;
    private String name;
    private String email;
    private String phone;
    private String department;
    private String specialization;
    private String officeHours;
    private LocalDateTime createdAt;

    public Instructor() {}

    public Instructor(String instructorId, String name, String email, String phone, 
                     String department, String specialization, String officeHours) {
        this.instructorId = instructorId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.department = department;
        this.specialization = specialization;
        this.officeHours = officeHours;
    }

    // Getters and Setters
    public String getInstructorId() { return instructorId; }
    public void setInstructorId(String instructorId) { this.instructorId = instructorId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getSpecialization() { return specialization; }
    public void setSpecialization(String specialization) { this.specialization = specialization; }

    public String getOfficeHours() { return officeHours; }
    public void setOfficeHours(String officeHours) { this.officeHours = officeHours; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
}