package com.courseregistration.view;

import com.courseregistration.dao.CourseDAO;
import com.courseregistration.dao.RegistrationDAO;
import com.courseregistration.model.Course;
import com.courseregistration.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class InstructorSchedulePanel extends JPanel {
    private CourseDAO courseDAO;
    private RegistrationDAO registrationDAO;
    private User currentUser;
    private JTable scheduleTable;
    private DefaultTableModel tableModel;
    private JButton btnRefresh;
    
    public InstructorSchedulePanel(User currentUser) {
        this.currentUser = currentUser;
        this.courseDAO = new CourseDAO();
        this.registrationDAO = new RegistrationDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadSchedule();
    }
    
    private void initializeComponents() {
        String[] columns = {"Course Code", "Course Title", "Day", "Time", "Location", "Credits", "Enrolled"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        scheduleTable = new JTable(tableModel);
        btnRefresh = new JButton("Refresh");
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBorder(BorderFactory.createTitledBorder("My Teaching Schedule"));
        headerPanel.add(btnRefresh, BorderLayout.EAST);
        
        add(headerPanel, BorderLayout.NORTH);
        add(new JScrollPane(scheduleTable), BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnRefresh.addActionListener(e -> loadSchedule());
    }
    
    private void loadSchedule() {
        tableModel.setRowCount(0);
        List<Course> courses = courseDAO.getAll();
        
        for (Course course : courses) {
            if (currentUser.getUserId().equals(course.getInstructorId())) {
                int activeEnrolled = registrationDAO.getByCourseCode(course.getCourseCode()).size();
                Object[] row = {
                    course.getCourseCode(),
                    course.getTitle(),
                    course.getScheduleDays() != null ? course.getScheduleDays() : "TBD",
                    course.getScheduleTime() != null ? course.getScheduleTime() : "TBD",
                    course.getLocation() != null ? course.getLocation() : "TBD",
                    course.getCredits(),
                    activeEnrolled + "/" + course.getCapacity()
                };
                tableModel.addRow(row);
            }
        }
    }
}