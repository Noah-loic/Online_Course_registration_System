package com.courseregistration.view;

import com.courseregistration.controller.RegistrationController;
import com.courseregistration.controller.CourseController;
import com.courseregistration.model.Registration;
import com.courseregistration.model.Course;
import com.courseregistration.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class StudentCompletedCoursesPanel extends JPanel {
    private RegistrationController registrationController;
    private CourseController courseController;
    private User currentUser;
    private JTable completedCoursesTable;
    private DefaultTableModel tableModel;
    private JLabel lblTotalCredits, lblGPA;
    
    public StudentCompletedCoursesPanel(User currentUser) {
        this.currentUser = currentUser;
        registrationController = new RegistrationController();
        courseController = new CourseController();
        
        initializeComponents();
        setupLayout();
        refreshTable();
    }
    
    private void initializeComponents() {
        // Table
        String[] columnNames = {"Course Code", "Course Title", "Credits", "Grade", "Grade Point"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        completedCoursesTable = new JTable(tableModel);
        completedCoursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Summary labels
        lblTotalCredits = new JLabel("Total Credits: 0");
        lblGPA = new JLabel("GPA: N/A");
        lblTotalCredits.setFont(new Font("Arial", Font.BOLD, 14));
        lblGPA.setFont(new Font("Arial", Font.BOLD, 14));
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Summary panel with modern cards
        JPanel summaryPanel = new JPanel(new GridLayout(1, 2, 15, 0));
        summaryPanel.setBackground(new Color(245, 245, 245));
        summaryPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        // Credits card
        JPanel creditsCard = createSummaryCard("Total Credits", lblTotalCredits, new Color(40, 167, 69));
        JPanel gpaCard = createSummaryCard("GPA", lblGPA, new Color(70, 130, 180));
        
        summaryPanel.add(creditsCard);
        summaryPanel.add(gpaCard);
        
        // Table panel with styling
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        JLabel tableTitle = new JLabel("Completed Courses");
        tableTitle.setFont(new Font("Arial", Font.BOLD, 18));
        tableTitle.setForeground(new Color(51, 51, 51));
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        // Style the table
        completedCoursesTable.setFont(new Font("Arial", Font.PLAIN, 12));
        completedCoursesTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        completedCoursesTable.getTableHeader().setBackground(new Color(70, 130, 180));
        completedCoursesTable.getTableHeader().setForeground(Color.WHITE);
        completedCoursesTable.setRowHeight(25);
        completedCoursesTable.setGridColor(new Color(230, 230, 230));
        completedCoursesTable.setSelectionBackground(new Color(184, 207, 229));
        
        JScrollPane scrollPane = new JScrollPane(completedCoursesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        
        tablePanel.add(tableTitle, BorderLayout.NORTH);
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        add(summaryPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
    }
    
    private JPanel createSummaryCard(String title, JLabel valueLabel, Color accentColor) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        titleLabel.setForeground(Color.GRAY);
        
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(accentColor);
        
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        
        return card;
    }
    
    private void refreshTable() {
        tableModel.setRowCount(0);
        // Use user ID which contains the student ID
        String studentId = currentUser.getUserId();
        List<Registration> registrations = registrationController.getStudentRegistrations(studentId);
        
        int totalCredits = 0;
        double totalGradePoints = 0;
        int gradedCourses = 0;
        
        for (Registration registration : registrations) {
            if ("COMPLETED".equals(registration.getStatus())) {
                Course course = courseController.getCourseByCode(registration.getCourseCode());
                String courseTitle = course != null ? course.getTitle() : "Unknown";
                int credits = course != null ? course.getCredits() : 0;
                
                String grade = registration.getGrade() != null ? registration.getGrade() : "N/A";
                double gradePoint = getGradePoint(grade);
                String gradePointStr = gradePoint >= 0 ? String.format("%.1f", gradePoint) : "N/A";
                
                Object[] row = {
                    registration.getCourseCode(),
                    courseTitle,
                    credits,
                    grade,
                    gradePointStr
                };
                tableModel.addRow(row);
                
                totalCredits += credits;
                
                // Calculate GPA if grade is available
                if (registration.getGrade() != null && !registration.getGrade().isEmpty()) {
                    double gpaGradePoint = getGradePoint(registration.getGrade());
                    if (gpaGradePoint >= 0) {
                        totalGradePoints += gpaGradePoint * credits;
                        gradedCourses += credits;
                    }
                }
            }
        }
        
        // Update summary
        lblTotalCredits.setText("Total Credits: " + totalCredits);
        if (gradedCourses > 0) {
            double gpa = totalGradePoints / gradedCourses;
            lblGPA.setText(String.format("GPA: %.2f", gpa));
        } else {
            lblGPA.setText("GPA: N/A");
        }
    }
    
    private double getGradePoint(String grade) {
        switch (grade.toUpperCase()) {
            case "A": return 4.0;
            case "A-": return 3.7;
            case "B+": return 3.3;
            case "B": return 3.0;
            case "B-": return 2.7;
            case "C+": return 2.3;
            case "C": return 2.0;
            case "C-": return 1.7;
            case "D+": return 1.3;
            case "D": return 1.0;
            case "F": return 0.0;
            default: return -1; // Invalid grade
        }
    }
}