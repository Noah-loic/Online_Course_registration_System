package com.courseregistration.view;

import com.courseregistration.dao.PaymentDAO;
import com.courseregistration.dao.RegistrationDAO;
import com.courseregistration.dao.CourseDAO;
import com.courseregistration.model.Payment;
import com.courseregistration.model.Course;
import com.courseregistration.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.math.BigDecimal;
import java.util.List;

public class StudentPaymentPanel extends JPanel {
    private PaymentDAO paymentDAO;
    private RegistrationDAO registrationDAO;
    private CourseDAO courseDAO;
    private User currentUser;
    private JTable feesTable, paymentsTable;
    private DefaultTableModel feesModel, paymentsModel;
    private JLabel lblTotalAmount, lblRegFee, lblLifeInsurance, lblGraduation, lblGrandTotal;
    private JButton btnMakePayment, btnRefresh;
    
    public StudentPaymentPanel(User currentUser) {
        this.currentUser = currentUser;
        this.paymentDAO = new PaymentDAO();
        this.registrationDAO = new RegistrationDAO();
        this.courseDAO = new CourseDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadFeesData();
        loadPaymentHistory();
    }
    
    private void initializeComponents() {
        // Fees summary table
        String[] feesColumns = {"CODE", "COURSE", "CREDITS", "CREDIT COST", "AMOUNT"};
        feesModel = new DefaultTableModel(feesColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        feesTable = new JTable(feesModel);
        
        // Payment history table
        String[] paymentColumns = {"Payment ID", "Amount", "Type", "Method", "Status", "Date", "Receipt #"};
        paymentsModel = new DefaultTableModel(paymentColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        paymentsTable = new JTable(paymentsModel);
        
        // Labels for totals
        lblTotalAmount = new JLabel("0.00 RWF");
        lblRegFee = new JLabel("25,000.00 RWF");
        lblLifeInsurance = new JLabel("10,000.00 RWF");
        lblGraduation = new JLabel("0.00 RWF");
        lblGrandTotal = new JLabel("0.00 RWF");
        
        // Buttons
        btnMakePayment = new JButton("Make Payment");
        btnRefresh = new JButton("Refresh");
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Main panel with vertical layout
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        // Fees summary section
        JPanel feesPanel = new JPanel(new BorderLayout());
        feesPanel.setBorder(BorderFactory.createTitledBorder("Fees summary"));
        feesPanel.add(new JScrollPane(feesTable), BorderLayout.CENTER);
        
        // Totals panel
        JPanel totalsPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.anchor = GridBagConstraints.WEST;
        
        // Course fees total
        gbc.gridx = 0; gbc.gridy = 0;
        totalsPanel.add(new JLabel("Course Fees:"), gbc);
        gbc.gridx = 1;
        totalsPanel.add(lblTotalAmount, gbc);
        
        // Registration fee
        gbc.gridx = 2; gbc.gridy = 0;
        totalsPanel.add(new JLabel("Reg. Fee:"), gbc);
        gbc.gridx = 3;
        totalsPanel.add(lblRegFee, gbc);
        
        // Life insurance
        gbc.gridx = 4; gbc.gridy = 0;
        totalsPanel.add(new JLabel("Life Assurance Fee:"), gbc);
        gbc.gridx = 5;
        totalsPanel.add(lblLifeInsurance, gbc);
        
        // Graduation fee
        gbc.gridx = 6; gbc.gridy = 0;
        totalsPanel.add(new JLabel("Graduation Fee:"), gbc);
        gbc.gridx = 7;
        totalsPanel.add(lblGraduation, gbc);
        
        // Grand total
        gbc.gridx = 8; gbc.gridy = 0;
        totalsPanel.add(new JLabel("Total:"), gbc);
        gbc.gridx = 9;
        lblGrandTotal.setFont(lblGrandTotal.getFont().deriveFont(Font.BOLD));
        totalsPanel.add(lblGrandTotal, gbc);
        
        feesPanel.add(totalsPanel, BorderLayout.SOUTH);
        
        // Payment history section
        JPanel historyPanel = new JPanel(new BorderLayout());
        historyPanel.setBorder(BorderFactory.createTitledBorder("Payment History"));
        historyPanel.add(new JScrollPane(paymentsTable), BorderLayout.CENTER);
        
        // Button panel
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnMakePayment);
        buttonPanel.add(btnRefresh);
        historyPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setTopComponent(feesPanel);
        splitPane.setBottomComponent(historyPanel);
        splitPane.setDividerLocation(300);
        
        add(splitPane, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnMakePayment.addActionListener(e -> makePayment());
        btnRefresh.addActionListener(e -> {
            loadFeesData();
            loadPaymentHistory();
        });
    }
    
    private void loadFeesData() {
        feesModel.setRowCount(0);
        List<Course> studentCourses = registrationDAO.getStudentCourses(currentUser.getUserId());
        
        BigDecimal totalCourseFees = BigDecimal.ZERO;
        int totalCredits = 0;
        
        for (Course course : studentCourses) {
            BigDecimal creditCost = new BigDecimal("21407"); // Default credit cost
            BigDecimal courseAmount = creditCost.multiply(new BigDecimal(course.getCredits()));
            
            Object[] row = {
                course.getCourseCode(),
                course.getTitle(),
                course.getCredits(),
                creditCost,
                courseAmount
            };
            feesModel.addRow(row);
            
            totalCourseFees = totalCourseFees.add(courseAmount);
            totalCredits += course.getCredits();
        }
        
        // Add totals row
        Object[] totalsRow = {"", "", totalCredits, "107,035.00 RWF", totalCourseFees + ".00 RWF"};
        feesModel.addRow(totalsRow);
        
        // Update labels
        lblTotalAmount.setText(totalCourseFees + ".00 RWF");
        
        BigDecimal regFee = new BigDecimal("25000");
        BigDecimal lifeFee = new BigDecimal("10000");
        BigDecimal gradFee = new BigDecimal("0");
        BigDecimal grandTotal = totalCourseFees.add(regFee).add(lifeFee).add(gradFee);
        
        lblGrandTotal.setText(grandTotal + ".00 RWF");
    }
    
    private void loadPaymentHistory() {
        paymentsModel.setRowCount(0);
        List<Payment> payments = paymentDAO.getByStudentId(currentUser.getUserId());
        
        for (Payment payment : payments) {
            Object[] row = {
                payment.getPaymentId(),
                payment.getAmount(),
                payment.getPaymentType(),
                payment.getPaymentMethod(),
                payment.getStatus(),
                payment.getPaymentDate(),
                payment.getReceiptNumber()
            };
            paymentsModel.addRow(row);
        }
    }
    
    private void makePayment() {
        JDialog paymentDialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Make Payment", true);
        paymentDialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        JTextField txtAmount = new JTextField(15);
        JComboBox<String> cmbPaymentType = new JComboBox<>(new String[]{"TUITION", "REGISTRATION", "LIFE_INSURANCE"});
        JComboBox<String> cmbPaymentMethod = new JComboBox<>(new String[]{"CREDIT_CARD", "DEBIT_CARD", "BANK_TRANSFER", "CASH"});
        
        gbc.gridx = 0; gbc.gridy = 0;
        paymentDialog.add(new JLabel("Amount (RWF):"), gbc);
        gbc.gridx = 1;
        paymentDialog.add(txtAmount, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        paymentDialog.add(new JLabel("Payment Type:"), gbc);
        gbc.gridx = 1;
        paymentDialog.add(cmbPaymentType, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        paymentDialog.add(new JLabel("Payment Method:"), gbc);
        gbc.gridx = 1;
        paymentDialog.add(cmbPaymentMethod, gbc);
        
        JPanel buttonPanel = new JPanel();
        JButton btnPay = new JButton("Pay");
        JButton btnCancel = new JButton("Cancel");
        
        btnPay.addActionListener(e -> {
            try {
                BigDecimal amount = new BigDecimal(txtAmount.getText().trim());
                String paymentType = (String) cmbPaymentType.getSelectedItem();
                String paymentMethod = (String) cmbPaymentMethod.getSelectedItem();
                
                Payment payment = new Payment(currentUser.getUserId(), amount, paymentType, paymentMethod, null);
                payment.setTransactionId("TXN" + System.currentTimeMillis());
                payment.setReceiptNumber("RCP" + System.currentTimeMillis());
                payment.setStatus("COMPLETED");
                
                if (paymentDAO.insert(payment)) {
                    JOptionPane.showMessageDialog(paymentDialog, "Payment successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    paymentDialog.dispose();
                    loadPaymentHistory();
                } else {
                    JOptionPane.showMessageDialog(paymentDialog, "Payment failed!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(paymentDialog, "Please enter a valid amount!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        
        btnCancel.addActionListener(e -> paymentDialog.dispose());
        
        buttonPanel.add(btnPay);
        buttonPanel.add(btnCancel);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        paymentDialog.add(buttonPanel, gbc);
        
        paymentDialog.pack();
        paymentDialog.setLocationRelativeTo(this);
        paymentDialog.setVisible(true);
    }
}