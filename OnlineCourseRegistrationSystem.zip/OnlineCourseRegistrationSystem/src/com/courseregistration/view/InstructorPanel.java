package com.courseregistration.view;

import com.courseregistration.dao.InstructorDAO;
import com.courseregistration.model.Instructor;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class InstructorPanel extends JPanel {
    private InstructorDAO instructorDAO;
    private JTable instructorTable;
    private DefaultTableModel tableModel;
    private JTextField txtInstructorId, txtUsername, txtName, txtEmail, txtPhone, txtDepartment, txtSpecialization, txtOfficeHours;
    private JButton btnAdd, btnUpdate, btnDelete, btnRefresh;
    
    public InstructorPanel() {
        instructorDAO = new InstructorDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadInstructors();
    }
    
    private void initializeComponents() {
        String[] columns = {"ID", "Name", "Email", "Department", "Specialization"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        instructorTable = new JTable(tableModel);
        instructorTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        txtInstructorId = new JTextField(15);
        txtUsername = new JTextField(15);
        txtName = new JTextField(20);
        txtEmail = new JTextField(20);
        txtPhone = new JTextField(15);
        txtDepartment = new JTextField(15);
        txtSpecialization = new JTextField(25);
        txtOfficeHours = new JTextField(20);
        
        btnAdd = new JButton("Add");
        btnUpdate = new JButton("Update");
        btnDelete = new JButton("Delete");
        btnRefresh = new JButton("Refresh");
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Instructor details form
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Instructor Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        gbc.gridx = 0; gbc.gridy = 0; formPanel.add(new JLabel("Instructor ID:"), gbc);
        gbc.gridx = 1; formPanel.add(txtInstructorId, gbc);
        gbc.gridx = 0; gbc.gridy = 1; formPanel.add(new JLabel("Username:"), gbc);
        gbc.gridx = 1; formPanel.add(txtUsername, gbc);
        gbc.gridx = 0; gbc.gridy = 2; formPanel.add(new JLabel("Name:"), gbc);
        gbc.gridx = 1; formPanel.add(txtName, gbc);
        gbc.gridx = 0; gbc.gridy = 3; formPanel.add(new JLabel("Email:"), gbc);
        gbc.gridx = 1; formPanel.add(txtEmail, gbc);
        gbc.gridx = 0; gbc.gridy = 4; formPanel.add(new JLabel("Phone:"), gbc);
        gbc.gridx = 1; formPanel.add(txtPhone, gbc);
        gbc.gridx = 0; gbc.gridy = 5; formPanel.add(new JLabel("Department:"), gbc);
        gbc.gridx = 1; formPanel.add(txtDepartment, gbc);
        gbc.gridx = 0; gbc.gridy = 6; formPanel.add(new JLabel("Specialization:"), gbc);
        gbc.gridx = 1; formPanel.add(txtSpecialization, gbc);
        gbc.gridx = 0; gbc.gridy = 7; formPanel.add(new JLabel("Office Hours:"), gbc);
        gbc.gridx = 1; formPanel.add(txtOfficeHours, gbc);
        
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnUpdate);
        buttonPanel.add(btnDelete);
        buttonPanel.add(btnRefresh);
        gbc.gridx = 0; gbc.gridy = 8; gbc.gridwidth = 2; formPanel.add(buttonPanel, gbc);
        
        JScrollPane scrollPane = new JScrollPane(instructorTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Instructors"));
        
        add(formPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnAdd.addActionListener(e -> addInstructor());
        btnUpdate.addActionListener(e -> updateInstructor());
        btnDelete.addActionListener(e -> deleteInstructor());
        btnRefresh.addActionListener(e -> loadInstructors());
        
        instructorTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedInstructor();
            }
        });
    }
    
    private void loadInstructors() {
        tableModel.setRowCount(0);
        List<Instructor> instructors = instructorDAO.getAll();
        
        for (Instructor instructor : instructors) {
            Object[] row = {
                instructor.getInstructorId(),
                instructor.getName(),
                instructor.getEmail(),
                instructor.getDepartment(),
                instructor.getSpecialization()
            };
            tableModel.addRow(row);
        }
    }
    
    private void loadSelectedInstructor() {
        int selectedRow = instructorTable.getSelectedRow();
        if (selectedRow >= 0) {
            txtInstructorId.setText((String) tableModel.getValueAt(selectedRow, 0));
            txtName.setText((String) tableModel.getValueAt(selectedRow, 1));
            txtEmail.setText((String) tableModel.getValueAt(selectedRow, 2));
            txtDepartment.setText((String) tableModel.getValueAt(selectedRow, 3));
            txtSpecialization.setText((String) tableModel.getValueAt(selectedRow, 4));
        }
    }
    
    private void addInstructor() {
        if (!validateInput()) return;
        
        Instructor instructor = new Instructor(
            txtInstructorId.getText().trim(),
            txtName.getText().trim(),
            txtEmail.getText().trim(),
            txtPhone.getText().trim(),
            txtDepartment.getText().trim(),
            txtSpecialization.getText().trim(),
            txtOfficeHours.getText().trim()
        );
        
        String result = instructorDAO.insert(instructor);
        if ("SUCCESS".equals(result)) {
            JOptionPane.showMessageDialog(this, "Instructor added successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadInstructors();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add instructor:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void updateInstructor() {
        if (!validateInput()) return;
        
        Instructor instructor = new Instructor(
            txtInstructorId.getText().trim(),
            txtName.getText().trim(),
            txtEmail.getText().trim(),
            txtPhone.getText().trim(),
            txtDepartment.getText().trim(),
            txtSpecialization.getText().trim(),
            txtOfficeHours.getText().trim()
        );
        
        String result = instructorDAO.update(instructor);
        if ("SUCCESS".equals(result)) {
            JOptionPane.showMessageDialog(this, "Instructor updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            clearForm();
            loadInstructors();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update instructor:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void deleteInstructor() {
        String instructorId = txtInstructorId.getText().trim();
        if (instructorId.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please select an instructor to delete!");
            return;
        }
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to delete this instructor?", 
            "Confirm Delete", 
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            String result = instructorDAO.delete(instructorId);
            if ("SUCCESS".equals(result)) {
                JOptionPane.showMessageDialog(this, "Instructor deleted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                clearForm();
                loadInstructors();
            } else {
                JOptionPane.showMessageDialog(this, "Failed to delete instructor:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    
    private boolean validateInput() {
        if (txtInstructorId.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Instructor ID is required!");
            return false;
        }
        if (txtName.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Name is required!");
            return false;
        }
        if (txtEmail.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Email is required!");
            return false;
        }
        return true;
    }
    
    private void clearForm() {
        txtInstructorId.setText("");
        txtUsername.setText("");
        txtName.setText("");
        txtEmail.setText("");
        txtPhone.setText("");
        txtDepartment.setText("");
        txtSpecialization.setText("");
        txtOfficeHours.setText("");
        instructorTable.clearSelection();
    }
}