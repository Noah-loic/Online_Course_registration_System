package com.courseregistration.view;

import com.courseregistration.dao.RegistrationDAO;
import com.courseregistration.model.Course;
import com.courseregistration.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class StudentRegistrationPanel extends JPanel {
    private RegistrationDAO registrationDAO;
    private User currentUser;
    private JTable myCoursesTable;
    private DefaultTableModel tableModel;
    private JButton btnRefresh;
    private JLabel lblTotalCredits;
    
    public StudentRegistrationPanel(User currentUser) {
        this.currentUser = currentUser;
        this.registrationDAO = new RegistrationDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadMyCourses();
    }
    
    private void initializeComponents() {
        // My courses table
        String[] columnNames = {"Course Code", "Course Title", "Credits", "Instructor", "Schedule", "Room", "Day", "Hour", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        myCoursesTable = new JTable(tableModel);
        myCoursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Buttons
        btnRefresh = new JButton("Refresh");
        
        // Total credits label
        lblTotalCredits = new JLabel("Total Credits: 0");
        lblTotalCredits.setFont(lblTotalCredits.getFont().deriveFont(Font.BOLD, 14f));
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 245));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Header panel with modern styling
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(Color.WHITE);
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));
        
        JLabel titleLabel = new JLabel("My Registered Courses");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(new Color(51, 51, 51));
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        lblTotalCredits.setFont(new Font("Arial", Font.BOLD, 16));
        lblTotalCredits.setForeground(new Color(70, 130, 180));
        headerPanel.add(lblTotalCredits, BorderLayout.EAST);
        
        // Table panel with styling
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Style the table
        myCoursesTable.setFont(new Font("Arial", Font.PLAIN, 12));
        myCoursesTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        myCoursesTable.getTableHeader().setBackground(new Color(70, 130, 180));
        myCoursesTable.getTableHeader().setForeground(Color.WHITE);
        myCoursesTable.setRowHeight(25);
        myCoursesTable.setGridColor(new Color(230, 230, 230));
        myCoursesTable.setSelectionBackground(new Color(184, 207, 229));
        
        JScrollPane scrollPane = new JScrollPane(myCoursesTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        
        // Button panel with styling
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(new Color(245, 245, 245));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        
        // Style the refresh button
        btnRefresh.setBackground(new Color(40, 167, 69));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFont(new Font("Arial", Font.BOLD, 12));
        btnRefresh.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
        btnRefresh.setFocusPainted(false);
        
        buttonPanel.add(btnRefresh);
        
        add(headerPanel, BorderLayout.NORTH);
        add(tablePanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
    }
    
    private void setupEventHandlers() {
        btnRefresh.addActionListener(e -> loadMyCourses());
    }
    
    private void loadMyCourses() {
        tableModel.setRowCount(0);
        List<Course> myCourses = registrationDAO.getStudentCourses(currentUser.getUserId());
        
        int totalCredits = 0;
        for (Course course : myCourses) {
            Object[] row = {
                course.getCourseCode(),
                course.getTitle(),
                course.getCredits(),
                course.getInstructorName(),
                course.getScheduleDays() + " " + course.getScheduleTime(),
                course.getLocation(),
                course.getScheduleDays(),
                course.getScheduleTime(),
                "ACTIVE"
            };
            tableModel.addRow(row);
            totalCredits += course.getCredits();
        }
        
        lblTotalCredits.setText("Total Credits: " + totalCredits);
    }
    
    private void dropSelectedCourse() {
        int selectedRow = myCoursesTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a course to drop!", "Selection Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String courseCode = (String) tableModel.getValueAt(selectedRow, 0);
        String courseTitle = (String) tableModel.getValueAt(selectedRow, 1);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to drop " + courseCode + " - " + courseTitle + "?", 
            "Confirm Drop", 
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            String result = registrationDAO.dropCourse(currentUser.getUserId(), courseCode);
            
            if ("SUCCESS".equals(result)) {
                JOptionPane.showMessageDialog(this, "Successfully dropped course!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadMyCourses();
            } else {
                JOptionPane.showMessageDialog(this, "Drop failed:\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}