# **Online Course Registration System:** 

Chosen Topic: Online Course Registration System

This is a web-based application that enables students to browse courses, register for classes, view schedules, make payments, and allows admins to manage course offerings and enrollments.

# **Requirements Specification**

## **Online Course Registration System**

---

## **1\. FUNCTIONAL REQUIREMENTS**

Functional requirements describe what the system should do \- the specific behaviors, functions, and services it must provide.

### **1.1 User Authentication & Authorization**

**FR-1.1:** The system shall allow users to register with a unique username, email, and password.

**FR-1.2:** The system shall authenticate users through a secure login mechanism using username/email and password.

**FR-1.3:** The system shall support three user roles: Student, Instructor, and Administrator.

**FR-1.4:** The system shall restrict access to features based on user roles.

**FR-1.5:** The system shall provide password recovery functionality via email verification.

**FR-1.6:** The system shall allow users to update their profile information (email, phone, address).

**FR-1.7:** The system shall automatically log out users after 30 minutes of inactivity.

### **1.2 Course Management (Admin)**

**FR-2.1:** Administrators shall be able to create new courses with details including:

* Course code  
* Course name  
* Credits  
* Description  
* Prerequisites  
* Maximum enrollment capacity  
* Schedule (days, time, location)

**FR-2.2:** Administrators shall be able to edit existing course information.

**FR-2.3:** Administrators shall be able to delete or archive courses.

**FR-2.4:** Administrators shall be able to assign instructors to courses.

**FR-2.5:** Administrators shall be able to organize courses by department and semester.

**FR-2.6:** Administrators shall be able to set registration periods (start and end dates).

**FR-2.7:** Administrators shall be able to set course fees for each course.

### **1.3 Course Browsing & Search (Student)**

**FR-3.1:** Students shall be able to view a catalog of all available courses.

**FR-3.2:** Students shall be able to search courses by:

* Course code  
* Course name  
* Department  
* Instructor name  
* Credits  
* Schedule/time

**FR-3.3:** Students shall be able to filter courses by semester, department, and availability.

**FR-3.4:** The system shall display course details including prerequisites, enrollment status, and available seats.

**FR-3.5:** Students shall be able to view instructor information for each course.

### **1.4 Course Registration (Student)**

**FR-4.1:** Students shall be able to register for courses during the designated registration period.

**FR-4.2:** The system shall verify that students meet all course prerequisites before allowing registration.

**FR-4.3:** The system shall prevent students from registering for courses that are full.

**FR-4.4:** The system shall detect and prevent schedule conflicts (overlapping class times).

**FR-4.5:** The system shall enforce credit hour limits per semester (e.g., minimum 12, maximum 18 credits).

**FR-4.6:** Students shall be able to add courses to a shopping cart before final submission.

**FR-4.7:** The system shall calculate total tuition fees based on registered courses.

**FR-4.8:** Students shall be able to drop courses within the add/drop period without penalty.

**FR-4.9:** Students shall be able to withdraw from courses after the add/drop period (with grade implications).

**FR-4.10:** The system shall send confirmation notifications upon successful registration.

### **1.5 Registration Approval & Waitlist**

**FR-5.1:** The system shall automatically approve registrations that meet all requirements.

**FR-5.2:** Administrators shall be able to manually approve or reject registration requests requiring special permission.

**FR-5.3:** The system shall maintain a waitlist for full courses.

**FR-5.4:** The system shall automatically notify and enroll waitlisted students when seats become available.

**FR-5.5:** Students shall be able to view their position on waitlists.

### **1.6 Payment Processing**

**FR-6.1:** Students shall be able to view their fee statement showing all charges.

**FR-6.2:** The system shall integrate with external payment gateways (credit/debit cards, bank transfer).

**FR-6.3:** The system shall record all payment transactions with timestamps and receipt numbers.

**FR-6.4:** Students shall be able to download/print payment receipts.

**FR-6.5:** The system shall send payment confirmation via email/SMS.

**FR-6.6:** Administrators shall be able to apply financial aid, scholarships, or discounts to student accounts.

**FR-6.7:** The system shall generate payment reminders for outstanding fees.

**FR-6.8:** The system shall support partial payments and installment plans.

### **1.7 Timetable & Schedule Management**

**FR-7.1:** The system shall automatically generate a personalized timetable for each student based on registered courses.

**FR-7.2:** Students shall be able to view their timetable in daily, weekly, and monthly formats.

**FR-7.3:** Students shall be able to export their timetable (PDF, iCal format).

**FR-7.4:** The system shall highlight schedule conflicts before course registration.

**FR-7.5:** Instructors shall be able to view their teaching schedule.

**FR-7.6:** The system shall send schedule reminders and updates when changes occur.

### **1.8 Instructor Features**

**FR-8.1:** Instructors shall be able to view their assigned courses.

**FR-8.2:** Instructors shall be able to view the list of enrolled students in their courses.

**FR-8.3:** Instructors shall be able to download class rosters.

**FR-8.4:** Instructors shall be able to submit final grades for students.

**FR-8.5:** Instructors shall be able to post course announcements visible to enrolled students.

**FR-8.6:** Instructors shall be able to set office hours and availability.

### **1.9 Reporting & Analytics**

**FR-9.1:** Administrators shall be able to generate enrollment reports by course, department, and semester.

**FR-9.2:** Administrators shall be able to generate financial reports showing tuition revenue.

**FR-9.3:** Administrators shall be able to view course capacity utilization reports.

**FR-9.4:** Administrators shall be able to export reports in PDF, Excel, and CSV formats.

**FR-9.5:** Students shall be able to view their registration history and academic record.

**FR-9.6:** The system shall provide dashboard analytics showing key metrics (total enrollments, revenue, popular courses).

**FR-9.7:** Instructors shall be able to generate grade distribution reports for their courses.

