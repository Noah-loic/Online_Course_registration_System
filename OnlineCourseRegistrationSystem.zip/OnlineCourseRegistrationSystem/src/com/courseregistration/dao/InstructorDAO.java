package com.courseregistration.dao;

import com.courseregistration.model.Instructor;
import com.courseregistration.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InstructorDAO {
    
    public List<Instructor> getAll() {
        List<Instructor> instructors = new ArrayList<>();
        String sql = "SELECT * FROM instructors ORDER BY instructor_id";
        
        try (Connection conn = DatabaseUtil.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Instructor instructor = new Instructor();
                instructor.setInstructorId(rs.getString("instructor_id"));
                instructor.setName(rs.getString("name"));
                instructor.setEmail(rs.getString("email"));
                instructor.setPhone(rs.getString("phone"));
                instructor.setDepartment(rs.getString("department"));
                instructor.setSpecialization(rs.getString("specialization"));
                instructor.setOfficeHours(rs.getString("office_hours"));
                instructors.add(instructor);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving instructors: " + e.getMessage());
        }
        
        return instructors;
    }
    
    public Instructor getById(String instructorId) {
        String sql = "SELECT * FROM instructors WHERE instructor_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, instructorId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Instructor instructor = new Instructor();
                instructor.setInstructorId(rs.getString("instructor_id"));
                instructor.setName(rs.getString("name"));
                instructor.setEmail(rs.getString("email"));
                instructor.setPhone(rs.getString("phone"));
                instructor.setDepartment(rs.getString("department"));
                instructor.setSpecialization(rs.getString("specialization"));
                instructor.setOfficeHours(rs.getString("office_hours"));
                return instructor;
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving instructor: " + e.getMessage());
        }
        
        return null;
    }
    
    public String update(Instructor instructor) {
        String sql = "UPDATE instructors SET name = ?, email = ?, phone = ?, department = ?, specialization = ?, office_hours = ? WHERE instructor_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, instructor.getName());
            stmt.setString(2, instructor.getEmail());
            stmt.setString(3, instructor.getPhone());
            stmt.setString(4, instructor.getDepartment());
            stmt.setString(5, instructor.getSpecialization());
            stmt.setString(6, instructor.getOfficeHours());
            stmt.setString(7, instructor.getInstructorId());
            
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0 ? "SUCCESS" : "Instructor not found";
            
        } catch (SQLException e) {
            if (e.getErrorCode() == 1062) {
                return "Email already exists for another instructor";
            }
            return "Database error: " + e.getMessage();
        }
    }
    
    public String insert(Instructor instructor) {
        String sql = "INSERT INTO instructors (instructor_id, name, email, phone, department, specialization, office_hours) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, instructor.getInstructorId());
            stmt.setString(2, instructor.getName());
            stmt.setString(3, instructor.getEmail());
            stmt.setString(4, instructor.getPhone());
            stmt.setString(5, instructor.getDepartment());
            stmt.setString(6, instructor.getSpecialization());
            stmt.setString(7, instructor.getOfficeHours());
            
            return stmt.executeUpdate() > 0 ? "SUCCESS" : "Failed to insert instructor";
            
        } catch (SQLException e) {

            if (e.getErrorCode() == 1062) {
                return "Instructor ID or email already exists";
            }
            return "Database error: " + e.getMessage();
        }
    }
    
    public String delete(String instructorId) {
        String sql = "DELETE FROM instructors WHERE instructor_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, instructorId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0 ? "SUCCESS" : "Instructor not found";
            
        } catch (SQLException e) {
            return "Database error: " + e.getMessage();
        }
    }
}