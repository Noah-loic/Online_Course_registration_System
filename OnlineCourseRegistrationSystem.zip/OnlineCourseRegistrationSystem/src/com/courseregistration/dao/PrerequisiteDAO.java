package com.courseregistration.dao;

import com.courseregistration.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PrerequisiteDAO {
    
    public boolean insertPrerequisites(String courseCode, List<String> prerequisites) {
        // First delete existing prerequisites
        deletePrerequisites(courseCode);
        
        if (prerequisites == null || prerequisites.isEmpty()) {
            return true; // No prerequisites to insert
        }
        
        String sql = "INSERT INTO prerequisites (course_code, prerequisite_code) VALUES (?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            for (String prerequisite : prerequisites) {
                if (prerequisite != null && !prerequisite.trim().isEmpty()) {
                    stmt.setString(1, courseCode);
                    stmt.setString(2, prerequisite.trim());
                    stmt.addBatch();
                }
            }
            
            stmt.executeBatch();
            return true;
            
        } catch (SQLException e) {
            System.err.println("Error inserting prerequisites: " + e.getMessage());
            return false;
        }
    }
    
    public boolean deletePrerequisites(String courseCode) {
        String sql = "DELETE FROM prerequisites WHERE course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            stmt.executeUpdate();
            return true;
            
        } catch (SQLException e) {
            System.err.println("Error deleting prerequisites: " + e.getMessage());
            return false;
        }
    }
    
    public List<String> getPrerequisites(String courseCode) {
        List<String> prerequisites = new ArrayList<>();
        String sql = "SELECT prerequisite_code FROM prerequisites WHERE course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                prerequisites.add(rs.getString("prerequisite_code"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving prerequisites: " + e.getMessage());
        }
        
        return prerequisites;
    }
}