package com.courseregistration.view;

import com.courseregistration.controller.AuthController;
import com.courseregistration.model.User;
import com.courseregistration.util.DatabaseUtil;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private AuthController authController;
    private User currentUser;
    private JTabbedPane tabbedPane;
    private StudentPanel studentPanel;
    private CoursePanel coursePanel;
    private StudentCoursePanel studentCoursePanel;
    private RegistrationPanel registrationPanel;
    private StudentRegistrationPanel studentRegistrationPanel;
    private PaymentPanel paymentPanel;
    private StudentPaymentPanel studentPaymentPanel;
    private WaitlistPanel waitlistPanel;
    private DepartmentPanel departmentPanel;
    private InstructorPanel instructorPanel;
    private InstructorCoursePanel instructorCoursePanel;
    private InstructorSchedulePanel instructorSchedulePanel;
    private JLabel lblUserInfo;
    
    // Dashboard panels
    private AdminDashboardPanel adminDashboardPanel;
    private StudentDashboardPanel studentDashboardPanel;
    private InstructorDashboardPanel instructorDashboardPanel;
    private StudentCompletedCoursesPanel studentCompletedCoursesPanel;
    private RegistrationControlPanel registrationControlPanel;
    
    public MainFrame(AuthController authController) {
        this.authController = authController;
        this.currentUser = authController.getCurrentUser();
        initializeComponents();
        setupLayout();
        setupFrame();
        checkDatabaseConnection();
    }
    
    private void initializeComponents() {
        tabbedPane = new JTabbedPane();
        lblUserInfo = new JLabel("Welcome, " + currentUser.getUsername() + " (" + currentUser.getRole() + ")");
        
        // Initialize panels based on user role
        if ("ADMIN".equals(currentUser.getRole())) {
            adminDashboardPanel = new AdminDashboardPanel();
            registrationControlPanel = new RegistrationControlPanel();
            studentPanel = new StudentPanel();
            coursePanel = new CoursePanel();
            registrationPanel = new RegistrationPanel();
            paymentPanel = new PaymentPanel();
            waitlistPanel = new WaitlistPanel();
            departmentPanel = new DepartmentPanel();
            instructorPanel = new InstructorPanel();
        } else if ("STUDENT".equals(currentUser.getRole())) {
            studentDashboardPanel = new StudentDashboardPanel(currentUser);
            studentCoursePanel = new StudentCoursePanel(currentUser); // Course registration
            studentRegistrationPanel = new StudentRegistrationPanel(currentUser); // Student registrations
            studentPaymentPanel = new StudentPaymentPanel(currentUser); // Student payments
            studentCompletedCoursesPanel = new StudentCompletedCoursesPanel(currentUser); // Completed courses
        } else if ("INSTRUCTOR".equals(currentUser.getRole())) {
            instructorDashboardPanel = new InstructorDashboardPanel(currentUser);
            instructorCoursePanel = new InstructorCoursePanel(currentUser);
            instructorSchedulePanel = new InstructorSchedulePanel(currentUser);
        }
    }
    
    private void setupLayout() {
        // Add tabs based on user role
        if ("ADMIN".equals(currentUser.getRole())) {
            tabbedPane.addTab("Dashboard", adminDashboardPanel);
            tabbedPane.addTab("Registration Control", registrationControlPanel);
            tabbedPane.addTab("Students", studentPanel);
            tabbedPane.addTab("Courses", coursePanel);
            tabbedPane.addTab("Departments", departmentPanel);
            tabbedPane.addTab("Instructors", instructorPanel);
            tabbedPane.addTab("Registrations", registrationPanel);
            tabbedPane.addTab("Payments", paymentPanel);
            tabbedPane.addTab("Waitlist", waitlistPanel);
        } else if ("STUDENT".equals(currentUser.getRole())) {
            tabbedPane.addTab("Dashboard", studentDashboardPanel);
            tabbedPane.addTab("Course Registration", studentCoursePanel);
            tabbedPane.addTab("My Courses", studentRegistrationPanel);
            tabbedPane.addTab("Completed Courses", studentCompletedCoursesPanel);
            tabbedPane.addTab("Payments", studentPaymentPanel);
        } else if ("INSTRUCTOR".equals(currentUser.getRole())) {
            tabbedPane.addTab("Dashboard", instructorDashboardPanel);
            tabbedPane.addTab("My Courses", instructorCoursePanel);
            tabbedPane.addTab("My Schedule", instructorSchedulePanel);
        }
        
        // Style the tabbed pane
        tabbedPane.setFont(new Font("Arial", Font.BOLD, 12));
        tabbedPane.setBackground(Color.WHITE);
        tabbedPane.setForeground(new Color(51, 51, 51));
        
        add(tabbedPane, BorderLayout.CENTER);
        
        // Add menu bar with styling
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(70, 130, 180));
        menuBar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        
        JMenu accountMenu = new JMenu("Account");
        accountMenu.setForeground(Color.WHITE);
        accountMenu.setFont(new Font("Arial", Font.BOLD, 12));
        
        JMenuItem changePasswordItem = new JMenuItem("Change Password");
        JMenuItem logoutItem = new JMenuItem("Logout");
        
        changePasswordItem.addActionListener(e -> showChangePasswordDialog());
        logoutItem.addActionListener(e -> logout());
        
        accountMenu.add(changePasswordItem);
        accountMenu.addSeparator();
        accountMenu.add(logoutItem);
        menuBar.add(accountMenu);
        setJMenuBar(menuBar);
        
        // Add user info and status bar with styling
        JPanel statusBar = new JPanel(new BorderLayout());
        statusBar.setBackground(new Color(240, 240, 240));
        statusBar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY),
            BorderFactory.createEmptyBorder(8, 15, 8, 15)
        ));
        
        lblUserInfo.setFont(new Font("Arial", Font.BOLD, 12));
        lblUserInfo.setForeground(new Color(51, 51, 51));
        statusBar.add(lblUserInfo, BorderLayout.WEST);
        
        JLabel statusLabel = new JLabel("Online Course Registration System - Ready");
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 11));
        statusLabel.setForeground(Color.GRAY);
        statusBar.add(statusLabel, BorderLayout.CENTER);
        
        // Add styled logout button to status bar
        JButton btnLogout = new JButton("Logout");
        btnLogout.setBackground(new Color(220, 53, 69));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFont(new Font("Arial", Font.BOLD, 11));
        btnLogout.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        btnLogout.setFocusPainted(false);
        btnLogout.addActionListener(e -> logout());
        statusBar.add(btnLogout, BorderLayout.EAST);
        
        add(statusBar, BorderLayout.SOUTH);
    }
    
    private void setupFrame() {
        setTitle("Online Course Registration System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        // Set modern look and feel
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // Use default if system L&F not available
        }
        
        // Set application colors
        getContentPane().setBackground(new Color(245, 245, 245));
        
        // Set application icon (you can add an icon file)
        try {
            setIconImage(Toolkit.getDefaultToolkit().getImage("icon.png"));
        } catch (Exception e) {
            // Icon not found, continue without it
        }
    }
    
    private void checkDatabaseConnection() {
        SwingUtilities.invokeLater(() -> {
            if (!DatabaseUtil.testConnection()) {
                JOptionPane.showMessageDialog(this,
                    "Warning: Could not connect to database.\n" +
                    "Please ensure MySQL is running and the database is configured correctly.\n" +
                    "Check DatabaseUtil.java for connection settings.",
                    "Database Connection Warning",
                    JOptionPane.WARNING_MESSAGE);
            }
        });
    }
    
    private void showChangePasswordDialog() {
        JDialog dialog = new JDialog(this, "Change Password", true);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        JPasswordField txtOldPassword = new JPasswordField(15);
        JPasswordField txtNewPassword = new JPasswordField(15);
        JPasswordField txtConfirmPassword = new JPasswordField(15);
        
        gbc.gridx = 0; gbc.gridy = 0;
        dialog.add(new JLabel("Current Password:"), gbc);
        gbc.gridx = 1;
        dialog.add(txtOldPassword, gbc);
        
        gbc.gridx = 0; gbc.gridy = 1;
        dialog.add(new JLabel("New Password:"), gbc);
        gbc.gridx = 1;
        dialog.add(txtNewPassword, gbc);
        
        gbc.gridx = 0; gbc.gridy = 2;
        dialog.add(new JLabel("Confirm Password:"), gbc);
        gbc.gridx = 1;
        dialog.add(txtConfirmPassword, gbc);
        
        JPanel buttonPanel = new JPanel();
        JButton btnChange = new JButton("Change");
        JButton btnCancel = new JButton("Cancel");
        
        btnChange.addActionListener(e -> {
            String oldPassword = new String(txtOldPassword.getPassword());
            String newPassword = new String(txtNewPassword.getPassword());
            String confirmPassword = new String(txtConfirmPassword.getPassword());
            
            if (!newPassword.equals(confirmPassword)) {
                JOptionPane.showMessageDialog(dialog, "New passwords do not match.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (authController.changePassword(oldPassword, newPassword)) {
                dialog.dispose();
            }
        });
        
        btnCancel.addActionListener(e -> dialog.dispose());
        
        buttonPanel.add(btnChange);
        buttonPanel.add(btnCancel);
        
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        dialog.add(buttonPanel, gbc);
        
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }
    
    private void logout() {
        int result = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to logout?",
            "Confirm Logout",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.QUESTION_MESSAGE
        );
        
        if (result == JOptionPane.YES_OPTION) {
            authController.logout();
            SwingUtilities.invokeLater(() -> {
                new LoginFrame().setVisible(true);
                this.dispose();
            });
        }
    }
    
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new LoginFrame().setVisible(true);
        });
    }
}