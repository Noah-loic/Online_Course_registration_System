package com.courseregistration.view;

import com.courseregistration.controller.CourseController;
import com.courseregistration.controller.RegistrationController;
import com.courseregistration.dao.RegistrationDAO;
import com.courseregistration.model.Course;
import com.courseregistration.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.util.List;

public class StudentCoursePanel extends JPanel {
    private CourseController courseController;
    private RegistrationController registrationController;
    private RegistrationDAO registrationDAO;
    private User currentUser;
    private JTable availableCoursesTable, myCoursesTable;
    private DefaultTableModel availableCoursesModel, myCoursesModel;
    private TableRowSorter<DefaultTableModel> sorter;
    private JButton btnRegister, btnDrop, btnRefresh, btnSearch;
    private JTextField txtSearch;
    private JComboBox<String> cmbSearchBy, cmbSemester, cmbDepartment;
    
    public StudentCoursePanel(User currentUser) {
        this.currentUser = currentUser;
        this.courseController = new CourseController();
        this.registrationController = new RegistrationController();
        this.registrationDAO = new RegistrationDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadCourses();
    }
    
    private void initializeComponents() {
        // Search components
        txtSearch = new JTextField(15);
        cmbSearchBy = new JComboBox<>(new String[]{"Course Name", "Course Code", "Department", "Instructor", "Credits"});
        cmbSemester = new JComboBox<>(new String[]{"All", "Fall", "Spring", "Summer"});
        cmbDepartment = new JComboBox<>(new String[]{"All"});
        btnSearch = new JButton("Search");
        
        // Available courses table
        String[] availableColumns = {"Course Code", "Title", "Credits", "Instructor", "Schedule", "Department", "Capacity", "Enrolled"};
        availableCoursesModel = new DefaultTableModel(availableColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        availableCoursesTable = new JTable(availableCoursesModel);
        availableCoursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Add sorting capability
        sorter = new TableRowSorter<>(availableCoursesModel);
        availableCoursesTable.setRowSorter(sorter);
        
        // My courses table
        String[] myColumns = {"Course Code", "Title", "Credits", "Instructor", "Schedule", "Status"};
        myCoursesModel = new DefaultTableModel(myColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        myCoursesTable = new JTable(myCoursesModel);
        myCoursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Buttons
        btnRegister = new JButton("Register for Course");
        btnDrop = new JButton("Drop Course");
        btnRefresh = new JButton("Refresh");
        
        loadDepartments();
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Course Catalog"));
        searchPanel.add(new JLabel("Search:"));
        searchPanel.add(txtSearch);
        searchPanel.add(cmbSearchBy);
        searchPanel.add(new JLabel("Semester:"));
        searchPanel.add(cmbSemester);
        searchPanel.add(new JLabel("Department:"));
        searchPanel.add(cmbDepartment);
        searchPanel.add(btnSearch);
        
        // Available courses panel
        JPanel availablePanel = new JPanel(new BorderLayout());
        availablePanel.add(new JScrollPane(availableCoursesTable), BorderLayout.CENTER);
        
        JPanel availableButtonPanel = new JPanel(new FlowLayout());
        availableButtonPanel.add(btnRegister);
        availablePanel.add(availableButtonPanel, BorderLayout.SOUTH);
        
        // Top panel combining search and available courses
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.add(searchPanel, BorderLayout.NORTH);
        topPanel.add(availablePanel, BorderLayout.CENTER);
        
        // My courses panel
        JPanel myCoursesPanel = new JPanel(new BorderLayout());
        myCoursesPanel.setBorder(BorderFactory.createTitledBorder("My Registered Courses"));
        myCoursesPanel.add(new JScrollPane(myCoursesTable), BorderLayout.CENTER);
        
        JPanel myCoursesButtonPanel = new JPanel(new FlowLayout());
        myCoursesButtonPanel.add(btnDrop);
        myCoursesButtonPanel.add(btnRefresh);
        myCoursesPanel.add(myCoursesButtonPanel, BorderLayout.SOUTH);
        
        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topPanel, myCoursesPanel);
        splitPane.setDividerLocation(350);
        splitPane.setResizeWeight(0.6);
        
        add(splitPane, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnRegister.addActionListener(e -> registerForCourse());
        btnDrop.addActionListener(e -> dropCourse());
        btnRefresh.addActionListener(e -> loadCourses());
        btnSearch.addActionListener(e -> performSearch());
        txtSearch.addActionListener(e -> performSearch());
    }
    
    private void loadCourses() {
        loadAvailableCourses();
        loadMyCourses();
    }
    
    private void loadAvailableCourses() {
        availableCoursesModel.setRowCount(0);
        List<Course> courses = courseController.getAllCourses();
        
        for (Course course : courses) {
            if (course.isActive()) {
                String schedule = "";
                if (course.getScheduleDays() != null && course.getScheduleTime() != null) {
                    schedule = course.getScheduleDays() + " " + course.getScheduleTime();
                } else if (course.getScheduleTime() != null) {
                    schedule = course.getScheduleTime();
                } else {
                    schedule = "TBD";
                }
                
                Object[] row = {
                    course.getCourseCode(),
                    course.getTitle(),
                    course.getCredits(),
                    course.getInstructorName() != null ? course.getInstructorName() : "TBD",
                    schedule,
                    course.getDepartment() != null ? course.getDepartment() : "TBD",
                    course.getCapacity(),
                    course.getEnrolledCount()
                };
                availableCoursesModel.addRow(row);
            }
        }
    }
    
    private void loadMyCourses() {
        myCoursesModel.setRowCount(0);
        List<Course> myCourses = registrationDAO.getStudentCourses(currentUser.getUserId());
        
        for (Course course : myCourses) {
            Object[] row = {
                course.getCourseCode(),
                course.getTitle(),
                course.getCredits(),
                course.getInstructorName(),
                course.getScheduleTime(),
                "ACTIVE" // You can get actual status from registration table
            };
            myCoursesModel.addRow(row);
        }
    }
    
    private void loadDepartments() {
        List<Course> courses = courseController.getAllCourses();
        courses.stream()
            .map(Course::getDepartment)
            .distinct()
            .sorted()
            .forEach(dept -> cmbDepartment.addItem(dept));
    }
    
    private void performSearch() {
        String searchText = txtSearch.getText().trim().toLowerCase();
        String searchBy = (String) cmbSearchBy.getSelectedItem();
        String semester = (String) cmbSemester.getSelectedItem();
        String department = (String) cmbDepartment.getSelectedItem();
        
        sorter.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {
            @Override
            public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> entry) {
                // Search text filter
                if (!searchText.isEmpty()) {
                    String value = "";
                    switch (searchBy) {
                        case "Course Name":
                            value = entry.getStringValue(1).toLowerCase();
                            break;
                        case "Course Code":
                            value = entry.getStringValue(0).toLowerCase();
                            break;
                        case "Department":
                            value = entry.getStringValue(5).toLowerCase();
                            break;
                        case "Instructor":
                            value = entry.getStringValue(3).toLowerCase();
                            break;
                        case "Credits":
                            value = entry.getStringValue(2).toLowerCase();
                            break;
                    }
                    if (!value.contains(searchText)) return false;
                }
                
                // Department filter
                if (!"All".equals(department)) {
                    String courseDept = entry.getStringValue(5);
                    if (!department.equals(courseDept)) return false;
                }
                
                return true;
            }
        });
    }
    
    private void registerForCourse() {
        if (!RegistrationControlPanel.isRegistrationOpen()) {
            JOptionPane.showMessageDialog(this, "Registration is currently closed. Please contact the administrator.", "Registration Closed", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int selectedRow = availableCoursesTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a course to register for!");
            return;
        }
        
        int modelRow = availableCoursesTable.convertRowIndexToModel(selectedRow);
        String courseCode = (String) availableCoursesModel.getValueAt(modelRow, 0);
        
        if (registrationController.registerStudent(currentUser.getUserId(), courseCode)) {
            loadCourses();
        }
    }
    
    private void dropCourse() {
        if (!RegistrationControlPanel.isRegistrationOpen()) {
            JOptionPane.showMessageDialog(this, "Registration is currently closed. You cannot modify your courses.", "Registration Closed", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        int selectedRow = myCoursesTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a course to drop!");
            return;
        }
        
        String courseCode = (String) myCoursesModel.getValueAt(selectedRow, 0);
        
        int confirm = JOptionPane.showConfirmDialog(this, 
            "Are you sure you want to drop " + courseCode + "?", 
            "Confirm Drop", 
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            String result = registrationDAO.dropCourse(currentUser.getUserId(), courseCode);
            
            if ("SUCCESS".equals(result)) {
                JOptionPane.showMessageDialog(this, "Successfully dropped course!", "Success", JOptionPane.INFORMATION_MESSAGE);
                loadCourses();
            } else {
                JOptionPane.showMessageDialog(this, "Drop failed:\\n" + result, "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}