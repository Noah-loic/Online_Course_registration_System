package com.courseregistration.controller;

import com.courseregistration.dao.RegistrationDAO;
import com.courseregistration.dao.CourseDAO;
import com.courseregistration.dao.StudentDAO;
import com.courseregistration.dao.WaitlistDAO;
import com.courseregistration.dao.PrerequisiteDAO;
import com.courseregistration.model.Registration;
import com.courseregistration.model.Course;
import com.courseregistration.model.Student;
import com.courseregistration.model.Waitlist;

import javax.swing.*;
import java.time.LocalDate;
import java.util.List;

public class RegistrationController {
    private RegistrationDAO registrationDAO;
    private CourseDAO courseDAO;
    private StudentDAO studentDAO;
    private WaitlistDAO waitlistDAO;
    private PrerequisiteDAO prerequisiteDAO;
    
    public RegistrationController() {
        this.registrationDAO = new RegistrationDAO();
        this.courseDAO = new CourseDAO();
        this.studentDAO = new StudentDAO();
        this.waitlistDAO = new WaitlistDAO();
        this.prerequisiteDAO = new PrerequisiteDAO();
    }
    
    public boolean registerStudent(String studentId, String courseCode) {
        if (!validateRegistrationData(studentId, courseCode)) {
            return false;
        }
        
        // Check if student is already registered for this course
        if (registrationDAO.isStudentRegistered(studentId, courseCode)) {
            JOptionPane.showMessageDialog(null, "Student is already registered for this course.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Get course and student information
        Course course = courseDAO.getById(courseCode);
        Student student = studentDAO.getById(studentId);
        
        if (course == null) {
            JOptionPane.showMessageDialog(null, "Course not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (student == null) {
            JOptionPane.showMessageDialog(null, "Student not found.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Check prerequisites
        if (!checkPrerequisites(studentId, course)) {
            return false;
        }
        
        // Check credit limits
        if (!checkCreditLimits(studentId, course)) {
            return false;
        }
        
        // Check schedule conflicts
        if (hasScheduleConflict(studentId, course)) {
            JOptionPane.showMessageDialog(null, "Schedule conflict detected with existing registrations.", "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        // Check course capacity
        if (course.isFull()) {
            // Add to waitlist
            int position = waitlistDAO.getNextPosition(courseCode);
            Waitlist waitlistEntry = new Waitlist(studentId, courseCode, position);
            
            if (waitlistDAO.insert(waitlistEntry)) {
                JOptionPane.showMessageDialog(null, 
                    "Course is full. Student added to waitlist at position " + position + ".", 
                    "Added to Waitlist", 
                    JOptionPane.INFORMATION_MESSAGE);
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "Failed to add student to waitlist.", "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        
        // Register student
        Registration registration = new Registration(studentId, courseCode, LocalDate.now(), "ACTIVE");
        boolean success = registrationDAO.insert(registration);
        
        if (success) {
            JOptionPane.showMessageDialog(null, "Student registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Failed to register student.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        return success;
    }
    
    public boolean updateRegistration(int registrationId, String status, String grade) {
        Registration registration = new Registration();
        registration.setRegistrationId(registrationId);
        registration.setRegistrationDate(LocalDate.now());
        registration.setStatus(status);
        registration.setGrade(grade);
        
        boolean success = registrationDAO.update(registration);
        
        if (success) {
            JOptionPane.showMessageDialog(null, "Registration updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Failed to update registration.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        
        return success;
    }
    
    public boolean dropRegistration(int registrationId) {
        int confirm = JOptionPane.showConfirmDialog(null, 
            "Are you sure you want to drop this registration?", 
            "Confirm Drop", 
            JOptionPane.YES_NO_OPTION);
            
        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = registrationDAO.delete(registrationId);
            
            if (success) {
                JOptionPane.showMessageDialog(null, "Registration dropped successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to drop registration.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            
            return success;
        }
        
        return false;
    }
    
    public List<Registration> getAllRegistrations() {
        return registrationDAO.getAll();
    }
    
    public List<Registration> searchRegistrations(String courseCode, String studentId, String grade) {
        return registrationDAO.searchRegistrations(courseCode, studentId, grade);
    }
    
    public List<Registration> getStudentRegistrations(String studentId) {
        return registrationDAO.getByStudentId(studentId);
    }
    
    public boolean isStudentRegistered(String studentId, String courseCode) {
        return registrationDAO.isStudentRegistered(studentId, courseCode);
    }
    
    private boolean checkPrerequisites(String studentId, Course course) {
        List<String> prerequisites = prerequisiteDAO.getPrerequisites(course.getCourseCode());
        
        if (prerequisites == null || prerequisites.isEmpty()) {
            return true; // No prerequisites required
        }
        
        List<Registration> studentRegistrations = registrationDAO.getByStudentId(studentId);
        
        for (String prerequisite : prerequisites) {
            boolean hasPrerequisite = studentRegistrations.stream()
                .anyMatch(reg -> prerequisite.equals(reg.getCourseCode()) && 
                         "COMPLETED".equals(reg.getStatus()));
            
            if (!hasPrerequisite) {
                JOptionPane.showMessageDialog(null, 
                    "Missing prerequisite: " + prerequisite + " for course " + course.getCourseCode() + 
                    "\nYou must complete " + prerequisite + " before registering for this course.", 
                    "Prerequisites Not Met", 
                    JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }
        
        return true;
    }
    
    private boolean checkCreditLimits(String studentId, Course course) {
        Student student = studentDAO.getById(studentId);
        if (student == null) return false;
        
        List<Registration> activeRegistrations = registrationDAO.getByStudentId(studentId);
        int currentCredits = activeRegistrations.stream()
            .filter(reg -> "ACTIVE".equals(reg.getStatus()))
            .mapToInt(reg -> {
                Course c = courseDAO.getById(reg.getCourseCode());
                return c != null ? c.getCredits() : 0;
            })
            .sum();
        
        int totalCredits = currentCredits + course.getCredits();
        
        if (totalCredits > student.getMaxCredits()) {
            JOptionPane.showMessageDialog(null, 
                "Registration would exceed maximum credit limit of " + student.getMaxCredits() + 
                " credits. Current: " + currentCredits + ", Adding: " + course.getCredits(), 
                "Credit Limit Exceeded", 
                JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
    
    private boolean hasScheduleConflict(String studentId, Course newCourse) {
        List<Registration> activeRegistrations = registrationDAO.getByStudentId(studentId);
        
        for (Registration registration : activeRegistrations) {
            if ("ACTIVE".equals(registration.getStatus())) {
                Course existingCourse = courseDAO.getById(registration.getCourseCode());
                if (existingCourse != null && hasTimeConflict(existingCourse, newCourse)) {
                    return true;
                }
            }
        }
        
        return false;
    }
    
    private boolean hasTimeConflict(Course course1, Course course2) {
        // Simple conflict detection based on schedule days and times
        if (course1.getScheduleDays() == null || course2.getScheduleDays() == null) {
            return false;
        }
        
        // Check if courses share any common days
        String days1 = course1.getScheduleDays();
        String days2 = course2.getScheduleDays();
        
        for (char day : days1.toCharArray()) {
            if (days2.indexOf(day) >= 0) {
                // Same day, check time overlap
                if (course1.getScheduleTime() != null && course2.getScheduleTime() != null) {
                    // Simplified time conflict check
                    return course1.getScheduleTime().equals(course2.getScheduleTime());
                }
            }
        }
        
        return false;
    }
    
    private boolean validateRegistrationData(String studentId, String courseCode) {
        if (studentId == null || studentId.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Student ID is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        if (courseCode == null || courseCode.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Course code is required.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        return true;
    }
}