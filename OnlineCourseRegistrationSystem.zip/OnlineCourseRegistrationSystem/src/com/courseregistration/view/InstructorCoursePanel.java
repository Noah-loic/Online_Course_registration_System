package com.courseregistration.view;

import com.courseregistration.dao.CourseDAO;
import com.courseregistration.dao.RegistrationDAO;
import com.courseregistration.model.Course;
import com.courseregistration.model.Registration;
import com.courseregistration.model.User;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class InstructorCoursePanel extends JPanel {
    private CourseDAO courseDAO;
    private RegistrationDAO registrationDAO;
    private User currentUser;
    private JTable coursesTable, studentsTable;
    private DefaultTableModel coursesModel, studentsModel;
    private JButton btnRefresh, btnAssignGrade;
    private JTextField txtGrade;
    private JComboBox<String> cmbStatus;
    
    public InstructorCoursePanel(User currentUser) {
        this.currentUser = currentUser;
        this.courseDAO = new CourseDAO();
        this.registrationDAO = new RegistrationDAO();
        initializeComponents();
        setupLayout();
        setupEventHandlers();
        loadMyCourses();
    }
    
    private void initializeComponents() {
        // My courses table
        String[] coursesColumns = {"Course Code", "Title", "Credits", "Schedule", "Enrolled", "Capacity"};
        coursesModel = new DefaultTableModel(coursesColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        coursesTable = new JTable(coursesModel);
        coursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Students table
        String[] studentsColumns = {"Student ID", "Student Name", "Registration Date", "Status", "Grade"};
        studentsModel = new DefaultTableModel(studentsColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) { return false; }
        };
        studentsTable = new JTable(studentsModel);
        studentsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Controls
        txtGrade = new JTextField(5);
        cmbStatus = new JComboBox<>(new String[]{"ACTIVE", "COMPLETED", "DROPPED"});
        btnRefresh = new JButton("Refresh");
        btnAssignGrade = new JButton("Update Grade/Status");
    }
    
    private void setupLayout() {
        setLayout(new BorderLayout());
        
        // Courses panel
        JPanel coursesPanel = new JPanel(new BorderLayout());
        coursesPanel.setBorder(BorderFactory.createTitledBorder("My Assigned Courses"));
        coursesPanel.add(new JScrollPane(coursesTable), BorderLayout.CENTER);
        
        // Students panel
        JPanel studentsPanel = new JPanel(new BorderLayout());
        studentsPanel.setBorder(BorderFactory.createTitledBorder("Enrolled Students"));
        studentsPanel.add(new JScrollPane(studentsTable), BorderLayout.CENTER);
        
        // Grade assignment panel
        JPanel gradePanel = new JPanel(new FlowLayout());
        gradePanel.add(new JLabel("Grade:"));
        gradePanel.add(txtGrade);
        gradePanel.add(new JLabel("Status:"));
        gradePanel.add(cmbStatus);
        gradePanel.add(btnAssignGrade);
        gradePanel.add(btnRefresh);
        studentsPanel.add(gradePanel, BorderLayout.SOUTH);
        
        // Split pane
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setTopComponent(coursesPanel);
        splitPane.setBottomComponent(studentsPanel);
        splitPane.setDividerLocation(200);
        
        add(splitPane, BorderLayout.CENTER);
    }
    
    private void setupEventHandlers() {
        btnRefresh.addActionListener(e -> {
            loadMyCourses();
            loadStudentsForSelectedCourse();
        });
        
        btnAssignGrade.addActionListener(e -> assignGrade());
        
        coursesTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadStudentsForSelectedCourse();
            }
        });
        
        studentsTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                loadSelectedStudent();
            }
        });
    }
    
    private void loadMyCourses() {
        coursesModel.setRowCount(0);
        List<Course> courses = courseDAO.getAll();
        
        for (Course course : courses) {
            if (currentUser.getUserId().equals(course.getInstructorId())) {
                int activeEnrolled = registrationDAO.getByCourseCode(course.getCourseCode()).size();
                Object[] row = {
                    course.getCourseCode(),
                    course.getTitle(),
                    course.getCredits(),
                    (course.getScheduleDays() != null ? course.getScheduleDays() : "") + " " + (course.getScheduleTime() != null ? course.getScheduleTime() : ""),
                    activeEnrolled,
                    course.getCapacity()
                };
                coursesModel.addRow(row);
            }
        }
    }
    
    private void loadStudentsForSelectedCourse() {
        studentsModel.setRowCount(0);
        int selectedRow = coursesTable.getSelectedRow();
        if (selectedRow < 0) return;
        
        String courseCode = (String) coursesModel.getValueAt(selectedRow, 0);
        List<Registration> registrations = registrationDAO.getByCourseCode(courseCode);
        
        for (Registration reg : registrations) {
            Object[] row = {
                reg.getStudentId(),
                reg.getStudentName(),
                reg.getRegistrationDate(),
                reg.getStatus(),
                reg.getGrade() != null ? reg.getGrade() : ""
            };
            studentsModel.addRow(row);
        }
    }
    
    private void loadSelectedStudent() {
        int selectedRow = studentsTable.getSelectedRow();
        if (selectedRow >= 0) {
            String status = (String) studentsModel.getValueAt(selectedRow, 3);
            String grade = (String) studentsModel.getValueAt(selectedRow, 4);
            
            cmbStatus.setSelectedItem(status);
            txtGrade.setText(grade != null ? grade : "");
        }
    }
    
    private void assignGrade() {
        int selectedRow = studentsTable.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a student!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        int selectedCourseRow = coursesTable.getSelectedRow();
        if (selectedCourseRow < 0) {
            JOptionPane.showMessageDialog(this, "Please select a course first!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        String studentId = (String) studentsModel.getValueAt(selectedRow, 0);
        String courseCode = (String) coursesModel.getValueAt(selectedCourseRow, 0);
        String grade = txtGrade.getText().trim();
        String status = (String) cmbStatus.getSelectedItem();
        
        if (registrationDAO.updateGradeAndStatus(studentId, courseCode, grade, status)) {
            studentsModel.setValueAt(status, selectedRow, 3);
            studentsModel.setValueAt(grade, selectedRow, 4);
            JOptionPane.showMessageDialog(this, "Grade/Status updated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update grade/status!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}