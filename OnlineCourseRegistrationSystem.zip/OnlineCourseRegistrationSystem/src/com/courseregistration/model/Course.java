package com.courseregistration.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public class Course {
    private String courseCode;
    private String title;
    private int credits;
    private int capacity;
    private int enrolledCount;
    private String instructorId;
    private String instructorName;
    private String scheduleTime;
    private String scheduleDays;
    private String location;
    private String department;
    private String semesterId;
    private String description;
    private BigDecimal fee;
    private boolean isActive;
    private LocalDateTime createdAt;
    private List<String> prerequisites;

    public Course() {
        this.enrolledCount = 0;
        this.fee = BigDecimal.ZERO;
        this.isActive = true;
    }

    public Course(String courseCode, String title, int credits, int capacity, 
                  String instructorId, String scheduleTime, String scheduleDays, 
                  String location, String department, String semesterId, String description, BigDecimal fee) {
        this.courseCode = courseCode;
        this.title = title;
        this.credits = credits;
        this.capacity = capacity;
        this.instructorId = instructorId;
        this.scheduleTime = scheduleTime;
        this.scheduleDays = scheduleDays;
        this.location = location;
        this.department = department;
        this.semesterId = semesterId;
        this.description = description;
        this.fee = fee;
        this.enrolledCount = 0;
        this.isActive = true;
    }

    // Getters and Setters
    public String getCourseCode() { return courseCode; }
    public void setCourseCode(String courseCode) { this.courseCode = courseCode; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }

    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    public int getEnrolledCount() { return enrolledCount; }
    public void setEnrolledCount(int enrolledCount) { this.enrolledCount = enrolledCount; }

    public String getInstructorId() { return instructorId; }
    public void setInstructorId(String instructorId) { this.instructorId = instructorId; }

    public String getInstructorName() { return instructorName; }
    public void setInstructorName(String instructorName) { this.instructorName = instructorName; }

    public String getScheduleTime() { return scheduleTime; }
    public void setScheduleTime(String scheduleTime) { this.scheduleTime = scheduleTime; }

    public String getScheduleDays() { return scheduleDays; }
    public void setScheduleDays(String scheduleDays) { this.scheduleDays = scheduleDays; }

    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getSemesterId() { return semesterId; }
    public void setSemesterId(String semesterId) { this.semesterId = semesterId; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public BigDecimal getFee() { return fee; }
    public void setFee(BigDecimal fee) { this.fee = fee; }

    public boolean isActive() { return isActive; }
    public void setActive(boolean active) { isActive = active; }

    public List<String> getPrerequisites() { return prerequisites; }
    public void setPrerequisites(List<String> prerequisites) { this.prerequisites = prerequisites; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public boolean isFull() { return enrolledCount >= capacity; }
    public int getAvailableSeats() { return capacity - enrolledCount; }

    @Override
    public String toString() {
        return "Course{" +
                "courseCode='" + courseCode + '\'' +
                ", title='" + title + '\'' +
                ", credits=" + credits +
                ", instructor='" + instructorName + '\'' +
                '}';
    }
}