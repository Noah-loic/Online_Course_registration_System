package com.courseregistration.dao;

import com.courseregistration.model.Waitlist;
import com.courseregistration.util.DatabaseUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class WaitlistDAO {
    
    public boolean insert(Waitlist waitlist) {
        String sql = "INSERT INTO waitlist (student_id, course_code, position) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, waitlist.getStudentId());
            stmt.setString(2, waitlist.getCourseCode());
            stmt.setInt(3, waitlist.getPosition());
            
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error inserting waitlist entry: " + e.getMessage());
            return false;
        }
    }
    
    public boolean delete(int waitlistId) {
        String sql = "DELETE FROM waitlist WHERE waitlist_id = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setInt(1, waitlistId);
            return stmt.executeUpdate() > 0;
            
        } catch (SQLException e) {
            System.err.println("Error deleting waitlist entry: " + e.getMessage());
            return false;
        }
    }
    
    public List<Waitlist> getByCourseCode(String courseCode) {
        List<Waitlist> waitlist = new ArrayList<>();
        String sql = "SELECT w.*, s.name as student_name, c.title as course_title " +
                     "FROM waitlist w " +
                     "JOIN students s ON w.student_id = s.student_id " +
                     "JOIN courses c ON w.course_code = c.course_code " +
                     "WHERE w.course_code = ? " +
                     "ORDER BY w.position";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                Waitlist entry = new Waitlist();
                entry.setWaitlistId(rs.getInt("waitlist_id"));
                entry.setStudentId(rs.getString("student_id"));
                entry.setCourseCode(rs.getString("course_code"));
                entry.setPosition(rs.getInt("position"));
                entry.setWaitlistDate(rs.getTimestamp("waitlist_date").toLocalDateTime());
                entry.setNotified(rs.getBoolean("notified"));
                entry.setStudentName(rs.getString("student_name"));
                entry.setCourseTitle(rs.getString("course_title"));
                
                waitlist.add(entry);
            }
            
        } catch (SQLException e) {
            System.err.println("Error retrieving waitlist: " + e.getMessage());
        }
        
        return waitlist;
    }
    
    public int getNextPosition(String courseCode) {
        String sql = "SELECT COALESCE(MAX(position), 0) + 1 FROM waitlist WHERE course_code = ?";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1);
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting next position: " + e.getMessage());
        }
        
        return 1;
    }
    
    public Waitlist getFirstInLine(String courseCode) {
        String sql = "SELECT w.*, s.name as student_name, c.title as course_title " +
                     "FROM waitlist w " +
                     "JOIN students s ON w.student_id = s.student_id " +
                     "JOIN courses c ON w.course_code = c.course_code " +
                     "WHERE w.course_code = ? " +
                     "ORDER BY w.position " +
                     "LIMIT 1";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, courseCode);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                Waitlist entry = new Waitlist();
                entry.setWaitlistId(rs.getInt("waitlist_id"));
                entry.setStudentId(rs.getString("student_id"));
                entry.setCourseCode(rs.getString("course_code"));
                entry.setPosition(rs.getInt("position"));
                entry.setWaitlistDate(rs.getTimestamp("waitlist_date").toLocalDateTime());
                entry.setNotified(rs.getBoolean("notified"));
                entry.setStudentName(rs.getString("student_name"));
                entry.setCourseTitle(rs.getString("course_title"));
                
                return entry;
            }
            
        } catch (SQLException e) {
            System.err.println("Error getting first in waitlist: " + e.getMessage());
        }
        
        return null;
    }
}